﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Default2 : System.Web.UI.Page
{
    String strcon = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    string financialYear = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        txtIncreaseValue1.Focus();
        readfinacialYear();   
    }
        
     public void AdjustSalaryIncrease()
     {
         decimal totalIncrease = 0;
         string increase = "";
         string newFinancialyearValue="";
         int Year = DateTime.Now.Year + 1;
         increase = txtIncreaseValue1.Text + "." + txtIncreaseValue2.Text;
         newFinancialyearValue = financialYear.Substring(5, 4) +"/" + Year.ToString() ;
         totalIncrease = decimal.Parse(increase)/100;
         try
         {
             SqlCommand cmd = new SqlCommand();
             sqlcon.ConnectionString = strcon;
             cmd.Connection = sqlcon;
             cmd.CommandText = "UpdateSalaryScales";
             cmd.CommandType = CommandType.StoredProcedure;

             cmd.Parameters.Add("@Increase", SqlDbType.VarChar).Value = totalIncrease.ToString();
             cmd.Parameters.Add("@FinaNcial_Year", SqlDbType.VarChar).Value = newFinancialyearValue;
             sqlcon.Open();
             cmd.ExecuteNonQuery();
             sqlcon.Close();

             Message("Salary scales/notches are successfully increased by " + increase.ToString() + "% " +" for " + newFinancialyearValue +" financial year.");
    
         }
         catch (IOException)
         {

         }

         
     }
     public void Message(string msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + msg + "');", true);
    }
   
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }

    protected void readfinacialYear()
    {
        
        string queryString = "Select Financial_Year from salary_scale where [id] = @id";
          using (SqlConnection connection = new SqlConnection(strcon))
                    {
            SqlCommand command = new SqlCommand(queryString, connection);
            command.Parameters.AddWithValue("@id", 1);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
      try
      {
            while (reader.Read())
           {
            
            financialYear = (string)reader["Financial_Year"];

            if (int.Parse(financialYear.Substring(5, 4)) >= int.Parse(DateTime.Now.Year.ToString()))
            {
                if (DateTime.Now.Month == 4)
                {
                    btnUpdateSalaryScales.Enabled = true;
                    btnUpdateSalaryScales.Visible = true; 
                }
                else 
                {
                    btnUpdateSalaryScales.Enabled = false;
                    btnUpdateSalaryScales.Visible = false;
                }
                       
            }
            
        }
    }
          finally
            {
                 
                 reader.Close();
            }
        }
    }
   
    protected void btnSearchID_Click(object sender, EventArgs e)
    {
        AdjustSalaryIncrease();
    }
    protected void txtIncreaseValue1_TextChanged(object sender, EventArgs e)
    {
        if (txtIncreaseValue1.Text == string.Empty)
        {
            Message("Enter number.");
            txtIncreaseValue1.Focus();
            return;
        }
    }
    protected void txtIncreaseValue2_TextChanged(object sender, EventArgs e)
    {
        if (txtIncreaseValue2.Text == string.Empty)
        {
            Message("Enter number.");
            txtIncreaseValue2.Focus();
            return;
        }
    }
}