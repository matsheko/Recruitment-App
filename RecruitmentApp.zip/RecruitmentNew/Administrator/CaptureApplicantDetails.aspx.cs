﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections;
using System.Collections.Specialized;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    SqlConnection sqlcon3 = new SqlConnection();
    SqlConnection sqlcon4 = new SqlConnection();
    string postApplied, postRefno ;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
       
        if (!IsPostBack)
        {
            RadioButtonList1.SelectedValue = "South African";
            Label1.Visible = false;
            Label2.Visible = false;
            disableForeignControls();
            txtName.Focus();
            SetInitialRow();
            LoadFieldOfStudy();
            sqlcon4 = new SqlConnection(Conn);
            String sql4 = "Select * from PostDetails where Post_ref_no = '" + Request["id"].ToString() + "'";
            sqlcon4.Open();

            SqlCommand cmd4 = new SqlCommand(sql4, sqlcon4);
            SqlDataReader dr = cmd4.ExecuteReader();

            while (dr.Read())
            {

                txtIntorExtPost.Text = dr["internalOrExternal"].ToString();
                postApplied = dr["post_applied"].ToString();
                postRefno = dr["post_ref_no"].ToString();
                Label1.Text = dr["post_ref_no"].ToString();
                Label2.Text = dr["post_applied"].ToString();
                
            }
            dr.Close();
            sqlcon4.Close();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (txtSpecifyDisability.Enabled == true && txtSpecifyDisability.Text == string.Empty)
        {
            MessageValidate("Specify disability.");
            txtSpecifyDisability.Focus();
            return;
        }
        else if (txtCell.Text.Length < 10)
        {
            MessageValidate("Cell number must be 10 digits long.");
            txtCell.Focus();
            return;
        }
        else 
        {
            search_By_Ref_And_id();
            HttpPostRequest();
        }
       
    }
    public void MessageValidate(string message)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("<script type = 'text/javascript'>");
        sb.Append("window.onload=function(){");
        sb.Append("alert('");
        sb.Append(message);
        sb.Append("')};");
        sb.Append("</script>");
        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
    }

    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                   "alert(' " + msg + "');", true);
    }
    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Applicant details successfully saved.');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    public void calculateAge()
    {

        #region generating age and specifying gender from id number

        if (this.txtID.Text == "")
        {
            Message("Please enter the ID number");
            this.txtID.Focus();
        }
        else if (this.txtID.Text.Length != 13)
        {
            Message("South African ID must be 13 digits....");
            this.txtID.Focus();
        }
        else
        {

            int century = 1900, birthyear, age, today = DateTime.Today.Year, actualAge, gender;
            birthyear = century + int.Parse(txtID.Text.Substring(0, 2));
            gender = int.Parse(txtID.Text.Substring(6, 1));

            //G : Gender. 0-4 Female; 5-9 Male
            if (gender <= 4)
            {
                ddlGender.SelectedValue = "Female";
            }
            else
            {
                ddlGender.SelectedValue = "Male";
            }
            age = today - birthyear;

            if (age >= 100)
            {
                actualAge = age - 100;
                txtAge.Text = actualAge.ToString();
            }

            else
            {
                txtAge.Text = age.ToString();
            }


        }
        #endregion

    }
 
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlCountry.SelectedValue == "Select Country")
        //{
        //    Message("Please select country.");
        //}
        //else if (ddlCountry.SelectedValue == "ZA")
        //{
        //    txtID.Enabled = true;
        //    txtID.Focus();
        //    txtPassport.Enabled = false;
        //    txtPassport.Text = "";
        //    txtAge.Enabled = false;
        //    txtAge.Text = "";

        //    ddlGender.Enabled = false;
            
        //}
        //else
        //{
        //    txtPassport.Enabled = true;
        //    txtPassport.Focus();
        //    txtID.Enabled = false;
        //    txtID.Text = "";
        //    txtAge.Text = "";
        //    txtAge.Enabled = true;

        //    ddlGender.Enabled = true;
        //    ddlGender.SelectedIndex = 0;

        //}
    }
    protected void ddlDisability_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDisability.SelectedIndex == 0)
        {
            Message("Please select disability");
        }
        else if (ddlDisability.SelectedIndex == 1)
        {
            txtSpecifyDisability.Enabled = true;
        }
        else if (ddlDisability.SelectedIndex == 2)
        {
            txtSpecifyDisability.Enabled = false;
        }
    }

    protected void txtSpecifyDisability_TextChanged(object sender, EventArgs e)
    {
        //if (ddlDisability.SelectedIndex == 1 && txtSpecifyDisability.Text == null)
        //{
        //    Message("Please specify disability");
        //}
    }

    protected void ddlAdditionalQual_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAdditionalQual.SelectedIndex == 0)
        {
            Message("Please select additional Qualification.");
            
        }
        else if (ddlAdditionalQual.SelectedIndex == 1)
        {
            table1.Visible = true;
        }
        else if (ddlAdditionalQual.SelectedIndex == 2)
        {
            table1.Visible = false;
        }
    }

    public void search_By_Ref_And_id()
    {
        validate_fields();
        if (txtID.Text == "" && txtPassport.Text == "")
        {
            Message("Please enter ID / Passport number.");
        }
        else if (txtID.Text != "")
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;
            sqlcon.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SearchbyRefandID";

            cmd.Parameters.AddWithValue("@post_reference", Request.QueryString["id"].ToString());
            cmd.Parameters.AddWithValue("@idNo", txtID.Text.Trim());

            SqlDataReader sqldr = cmd.ExecuteReader();

            if (sqldr.HasRows == true)
            {
                Message("Applicant already exist.");
                sqlcon.Close();
            }
            else
            {
                InsertApplicant();
            }
        }
        else if (txtPassport.Text != "")
        {
            SqlCommand cmd2 = new SqlCommand();
            sqlcon2.ConnectionString = Conn;
            cmd2.Connection = sqlcon2;
            sqlcon2.Open();

            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.CommandText = "SearchbyRefandPassport";

            cmd2.Parameters.AddWithValue("@post_reference", Request.QueryString["id"].ToString());
            cmd2.Parameters.AddWithValue("@Passport", txtPassport.Text.Trim());

            SqlDataReader sqldr2 = cmd2.ExecuteReader();

            if (sqldr2.HasRows == true)
            {
                Message("Applicant already exist.");
                sqlcon2.Close();
            }
            else
            {
                InsertApplicant();
            }
        }
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex + 1;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data
                    dt.Rows.Remove(dt.Rows[rowID]);
                }
            }
            //Store the current data in ViewState for future reference
            ViewState["CurrentTable"] = dt;
            //Re bind the GridView for the updated data
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    public void InsertApplicant()
    {
       
        SqlCommand cmd3 = new SqlCommand();
        sqlcon3.ConnectionString = Conn;
        cmd3.Connection = sqlcon3;
        try
        {
            
            sqlcon3.Open();
            cmd3.CommandText = "insertApplicantDetails";
            cmd3.CommandType = CommandType.StoredProcedure;

            cmd3.Parameters.Add("@initials", SqlDbType.VarChar).Value = txtInitials.Text;
            cmd3.Parameters.Add("@full_names", SqlDbType.VarChar).Value = txtName.Text;
            cmd3.Parameters.Add("@Surname", SqlDbType.VarChar).Value = txtSurname.Text;
            cmd3.Parameters.Add("@citizenship", SqlDbType.VarChar).Value = ddlCountry.SelectedItem.Text;

            cmd3.Parameters.Add("@idNo", SqlDbType.VarChar).Value = txtID.Text;
            cmd3.Parameters.Add("@passport", SqlDbType.VarChar).Value = txtPassport.Text;
            cmd3.Parameters.Add("@age", SqlDbType.VarChar).Value = txtAge.Text;
            cmd3.Parameters.Add("@gender", SqlDbType.VarChar).Value = ddlGender.Text;
            cmd3.Parameters.Add("@disability", SqlDbType.VarChar).Value = ddlDisability.SelectedItem.Text;
            cmd3.Parameters.Add("@specify_disability", SqlDbType.VarChar).Value = txtSpecifyDisability.Text;

            if (ddlRace.Visible == false && txtOtherRace.Visible == true)
            {
                if (txtOtherRace.Text != "")
                {
                    cmd3.Parameters.Add("@race", SqlDbType.VarChar).Value = txtOtherRace.Text;
                }
                else
                {
                    Message("Please specify your Race");
                }
            }
            else
            {
                cmd3.Parameters.Add("@race", SqlDbType.VarChar).Value = ddlRace.SelectedItem.Text;
            }

            cmd3.Parameters.Add("@internal_external_post", SqlDbType.VarChar).Value = txtIntorExtPost.Text;

            cmd3.Parameters.Add("@working_experience", SqlDbType.VarChar).Value = ddlWorkExperience.SelectedItem.Text;

            cmd3.Parameters.Add("@related_experience", SqlDbType.VarChar).Value = ddlRelatedExperience.SelectedItem.Text;
            cmd3.Parameters.Add("@field_of_study", SqlDbType.VarChar).Value = ddlFieldOfStudy.SelectedItem.Text;
            cmd3.Parameters.Add("@type_of_qualification", SqlDbType.VarChar).Value = ddlQualification.SelectedItem.Text;
            cmd3.Parameters.Add("@additional_qualification", SqlDbType.VarChar).Value = ddlAdditionalQual.SelectedItem.Text;
            //cmd3.Parameters.Add("@list_qualification", SqlDbType.VarChar).Value = txtListQualification.Text;
            cmd3.Parameters.Add("@institution", SqlDbType.VarChar).Value = txtInstitution.Text;

            cmd3.Parameters.Add("@cell_phone", SqlDbType.VarChar).Value = "27" + txtCell.Text.Substring(1, 9);

            cmd3.Parameters.Add("@other_number", SqlDbType.VarChar).Value = txtOtherNumber.Text;
            cmd3.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = Request.QueryString["id"];
            cmd3.Parameters.Add("@captured_by", SqlDbType.VarChar).Value = Session["name"].ToString() + " " + Session["Surname"].ToString();

            cmd3.Parameters.Add("@recommend", SqlDbType.VarChar).Value = ddlRecommend.SelectedItem.Text;
            cmd3.Parameters.Add("@comments", SqlDbType.VarChar).Value = txtComments.Text;

            if (dpPermitExpDate.Enabled == true)
            {
                cmd3.Parameters.Add("@work_permit_exp_date", SqlDbType.DateTime).Value = dpPermitExpDate.Text;
            }
            else if(dpPermitExpDate.Enabled == false)
            {
                cmd3.Parameters.Add("@work_permit_exp_date", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (FileUpload1.HasFile)
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);

                FileUpload1.SaveAs(Server.MapPath("Work Permit/" + filename));
                cmd3.Parameters.AddWithValue("@work_permit", filename);
                cmd3.Parameters.AddWithValue("@work_permit_file_path", "Work Permit/" + filename);

            }
            else
            {
                cmd3.Parameters.AddWithValue("@work_permit", DBNull.Value);
                cmd3.Parameters.AddWithValue("@work_permit_file_path", DBNull.Value);

            }
            cmd3.Parameters.Add("@NewId", SqlDbType.Int).Direction = ParameterDirection.Output;

            cmd3.ExecuteNonQuery();

            int num = Convert.ToInt32(cmd3.Parameters["@NewId"].Value);
            this.Session["applicant_id"] = num;

            //Save to the additional qualifications table
            int rowIndex = 0;
            StringCollection sc = new StringCollection();
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        //extract the TextBox values
                        TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtQualification");
                        TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtInstitution");

                        //get the values from the TextBoxes
                        //then add it to the collections with a comma "," as the delimited values
                        sc.Add(box1.Text + "," + box2.Text + "," + this.Session["applicant_id"].ToString() + "," + Request.QueryString["id"].ToString());
                        rowIndex++;
                    }
                    //Call the method for executing inserts
                    InsertRecords(sc);
                }
            }
            sqlcon3.Close();
            ShowMessage("Applicant details successfully saved.");
            
        }
        catch
        {

        }
    }
    private void AddNewRowToGrid()
    {
        int rowIndex = 0;

        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtQualification");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtInstitution");

                    drCurrentRow = dtCurrentTable.NewRow();
                    //drCurrentRow["RowNumber"] = i + 1;

                    dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;

                    rowIndex++;
                }
                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                GridView1.DataSource = dtCurrentTable;
                GridView1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtQualification");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtInstitution");

                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();
                    
                    rowIndex++;
                }
            }
        }
    }
    private void SetInitialRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        //dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));
       
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;

        dt.Rows.Add(dr);
        //dr = dt.NewRow();

        //Store the DataTable in ViewState
        ViewState["CurrentTable"] = dt;

        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }

    private void InsertRecords(StringCollection sc)
    {
        SqlConnection Sqlconn = new SqlConnection();
        Sqlconn.ConnectionString = Conn;
        StringBuilder sb = new StringBuilder(string.Empty);
        string[] splitItems = null;
        foreach (string item in sc)
        {

            const string sqlStatement = "INSERT INTO additional_qualifications (additional_qualification, institution,applicant_id,post_reference) VALUES";
            if (item.Contains(","))
            {
                splitItems = item.Split(",".ToCharArray());
                sb.AppendFormat("{0}('{1}','{2}','{3}','{4}'); ", sqlStatement, splitItems[0], splitItems[1], splitItems[2], splitItems[3]);
            }

        }

        try
        {

            Sqlconn.Open();
            SqlCommand cmd = new SqlCommand(sb.ToString(), Sqlconn);

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

        }
        catch (System.Data.SqlClient.SqlException ex)
        {
            string msg = "Insert Error:";
            msg += ex.Message;
            throw new Exception(msg);

        }
        finally
        {
            Sqlconn.Close();
        }
    }
    public void validate_fields() 
    {
        if (txtName.Text == string.Empty) 
        {
            Message("Enter the first names.");
            txtName.Focus();
            return;
        }
        else if (txtInitials.Text == string.Empty) 
        {
            Message("Enter the initials.");
            txtInitials.Focus();
            return;
        }
        else if (txtSurname.Text == string.Empty) 
        {
            Message("Enter the surname.");
            txtSurname.Focus();
            return;
        }
        else if (ddlCountry.SelectedIndex == 0) 
        {
            Message("Select the country.");
            ddlCountry.Focus();
            return;
        }
        else if (txtPassport.Text == string.Empty && txtPassport.Enabled == true) 
        {
            Message("Enter the passport number.");
            txtPassport.Focus();
            return;
        }
        else if (FileUpload1.Enabled == true && FileUpload1.HasFile == false) 
        {
            Message("Upload work permit.");
            FileUpload1.Focus();
            return;
        }
        else if (dpPermitExpDate.Text == string.Empty && dpPermitExpDate.Enabled == true) 
        {
            Message("Enter work permit expiry date.");
            dpPermitExpDate.Focus();
            return;
        }
        //else if (txtSpecifyDisability.Enabled == true && txtSpecifyDisability.Text == string.Empty)
        //{
        //    MessageValidate("Specify disability.");
        //    txtSpecifyDisability.Focus();
        //    return;
        //}
        //else if (txtCell.Text.Length < 10) 
        //{
        //    MessageValidate("Cell number must be 10 digits long.");
        //    txtCell.Focus();
        //    return;
        //}
        else if (txtID.Text == string.Empty && txtID.Enabled == true)
        {
            Message("Enter the ID number.");
            txtID.Focus();
            return;
        }
        else if (txtAge.Text == string.Empty)
        {
            Message("Enter the Age.");
            txtAge.Focus();
            return;
        }
        else if (ddlGender.SelectedIndex == 0)
        {
            Message("Select the gender.");
            ddlGender.Focus();
            return;
        }
        else if (ddlDisability.SelectedIndex == 0)
        {
            Message("Select if you have disability.");
            ddlDisability.Focus();
            return;
        }
        else if (ddlDisability.SelectedItem.Text == "Select One...." && txtSpecifyDisability.Text == string.Empty)
        {
            Message("Enter disability field.");
            txtSpecifyDisability.Focus();
            return;
        }
        else if (ddlRace.SelectedIndex == 0)
        {
            Message("Select the race.");
            ddlRace.Focus();
            return;
        }
        else if (ddlWorkExperience.SelectedIndex == 0)
        {
            Message("Select the work experience.");
            ddlWorkExperience.Focus();
            return;
        }
        else if (ddlRelatedExperience.SelectedIndex == 0)
        {
            Message("Select the related experience.");
            ddlRelatedExperience.Focus();
            return;
        }
        else if (ddlFieldOfStudy.SelectedIndex == 0)
        {
            Message("Select the field of study.");
            ddlFieldOfStudy.Focus();
            return;
        }
        else if (ddlQualification.SelectedIndex == 0)
        {
            Message("Select the type of qualification.");
            ddlQualification.Focus();
            return;
        }
        else if (ddlAdditionalQual.SelectedIndex == 0)
        {
            Message("Select the addidtional qualification field.");
            ddlAdditionalQual.Focus();
            return;
        }
        //else if (txtListQualification.Text == string.Empty) 
        //{
        //    Message("List all the qualifications.");
        //    return;
        //}
        else if (txtInstitution.Text == string.Empty)
        {
            Message("Enter the institution field.");
            txtInstitution.Focus();
            return;
        }
        else if (txtCell.Text == string.Empty)
        {
            Message("Enter the cellphone field.");
            txtCell.Focus();
            return;
        }
    }
    protected void txtIDPassport_TextChanged(object sender, EventArgs e)
    {
        calculateAge();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void txtName_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtName.Text, @"^[a-zA-Z ]+$"))
        {
            
            ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert('Firstnames must be alphabets only..');", true);
            txtName.Focus();
        }
        Regex initials = new Regex(@"(\b[a-zA-Z])[a-zA-Z]* ?");
        string init = initials.Replace(txtName.Text, "$1");
        txtInitials.Text = init.ToUpper();
        txtInitials.Enabled = false;
    }
    protected void ddlRace_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRace.SelectedItem.Text == "Other")
        {
            txtOtherRace.Visible = true;
            txtOtherRace.Focus();
            ddlRace.Visible = false;
        }
        else if (ddlRace.SelectedItem.Text == "Select One....")
        {
            Message("Please select race");
        }
    }

    protected void LoadFieldOfStudy()
    {       

        SqlCommand selectCommand = new SqlCommand("select * from Field_Of_Study");
        this.sqlcon4.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlFieldOfStudy.DataSource = dataTable;
            this.ddlFieldOfStudy.DataTextField = "Description";
            this.ddlFieldOfStudy.DataValueField = "id";
            this.ddlFieldOfStudy.DataBind();
            this.ddlFieldOfStudy.Items.Insert(0, "Select One...");
            
        }
        sqlcon4.Close();
    }
    protected void LoadQualifications(int fieldOfStudyID)
    {
        SqlCommand cmd = new SqlCommand("select * from [dbo].[Qualifications] where Field_Of_Study = '"+ ddlFieldOfStudy.SelectedValue + "'");
        //cmd.Parameters.AddWithValue("@id", fieldOfStudyID);
        this.sqlcon4.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlQualification.DataSource = dataTable;
            this.ddlQualification.DataTextField = "Description";
            this.ddlQualification.DataValueField = "id";
            this.ddlQualification.DataBind();
            this.ddlQualification.Items.Insert(0, "Select One...");
        }
        sqlcon4.Close();
    }
    protected void ddlFieldOfStudy_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlFieldOfStudy.SelectedIndex != 0)
        {
            LoadQualifications(Convert.ToInt32(ddlFieldOfStudy.SelectedValue));
        }
        else
        {
            Message("Please select the field of study");
        }
    }
   

    public void showMessage(string message)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + message + "');", true);
    }
    protected void txtOtherRace_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtOtherRace.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Please enter alphabets only..");
            txtOtherRace.Text = string.Empty;
            txtOtherRace.Focus();
        }
    }
    protected void txtInstitution_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtInstitution.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Institution name must be alphabets only..");
            txtInstitution.Text = string.Empty;
            txtInstitution.Focus();
        }
    }
    protected void disableForeignControls()
    {
        FileUpload1.Enabled = false;
        txtPassport.Enabled = false;
        dpPermitExpDate.Enabled = false;
        txtAge.Enabled = false;
        ddlCountry.Items[193].Enabled = true;
        ddlCountry.SelectedIndex = 193;
        ddlCountry.Enabled = false;
        txtID.Text = string.Empty;
        txtID.Enabled = true;
    }
    protected void enableForeignControls()
    {
        FileUpload1.Enabled = true;
        txtPassport.Enabled = true;
        dpPermitExpDate.Enabled = true;
        txtAge.Enabled = true;
        ddlCountry.Enabled = true;
        ddlCountry.SelectedIndex = 0;
        ddlCountry.Items[193].Enabled = false;
        txtID.Text = string.Empty;
        txtID.Enabled = false;
        txtAge.Text= string.Empty;

    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "South African")
        {
            disableForeignControls();
        }
        else
        {
            enableForeignControls();
        }
    }
    private void HttpPostRequest()
    {
        try
        {
            string clientid = "483928";
            string clientsecret = "X4FnITeDil";
            //string clientid = "WSIF49";
            //string clientsecret = "NgIfIhxP";
            //string accesstoken = "3432753";
            string accesstoken = "ZTA6gcqCKJ";
           
            string destination = "27" + txtCell.Text.Substring(1, 9);
            //Label1.Text = dr["post_ref_no"].ToString();
            //Label2.Text = dr["post_applied"].ToString();
            string message = "GPDRT RSS." + "Your application of " + Label2.Text + " ," + "ref no: " + Label1.Text + " " + "has been received.";

            ASCIIEncoding encoding = new ASCIIEncoding();
            string postData = "clientid=" + clientid + "&clientsecret=" + clientsecret + "&accesstoken=" + accesstoken + "&destination=" + destination + "&message=" + message;
            //string postData = "clientid=" + clientid + "&clientsecret=" + clientsecret + "&accesstoken=" + accesstoken + "&destination=" + destination + "&message=" + message;
            byte[] data = encoding.GetBytes(postData);
            WebRequest request = WebRequest.Create("http://ec2-52-89-90-159.us-west-2.compute.amazonaws.com:3006/gpdrt/messaging");
            //WebRequest request = WebRequest.Create("http://ec2-52-88-13-189.us-west-2.compute.amazonaws.com:8080/gpdrt/messaging");
            
            //WebRequest request = WebRequest.Create("http://52.89.90.159:3006/gpdrt/messaging");
            request.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
            request.Method = "Post";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;
            request.UseDefaultCredentials = true;

            Stream stream = request.GetRequestStream();
            stream.Write(data,0, data.Length);
            stream.Close();

            WebResponse responce = request.GetResponse();
            stream = responce.GetResponseStream();

            StreamReader sr = new StreamReader(stream);
           
            Message(sr.ReadToEnd().ToString()); 
            
            sr.Close();
            stream.Close();          

        }

        catch (Exception ex)
        {        
           Message(ex.Message);
           txtComments.Text = ex.ToString();          
        }
    }

}

