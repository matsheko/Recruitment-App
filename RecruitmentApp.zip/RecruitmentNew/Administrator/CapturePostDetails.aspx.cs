﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections.Specialized;
using System.Text;
using System.Drawing;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    SqlConnection sqlcon3 = new SqlConnection();
    SqlConnection sqlcon4 = new SqlConnection();
    int count;
    string results;

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        try
        {

            if (!base.IsPostBack)
            {
                LoadAgencies();
                this.LoadBranch_advertised_post();
                ddlChief_Directorate_advertised_post.Enabled = false;
                ddlDirectorate_advertised_post.Enabled = false;
                ddlComponet_advertised_post.Enabled = false;

                lblComments.Visible = false;
                txtComments.Visible = false;

                ddlOSDPost_grade.Enabled = false;
                ddlOSDCategory.Enabled = false;
            }
            //GetPostRefNo();
            countRows();
        }
        catch
        {

        }
    }
    public void countRows()
    {
        sqlcon = new SqlConnection(Conn);
        sqlcon.Open();
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) as Tot FROM [dbo].[PostDetails]", sqlcon);
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            count = Convert.ToInt32(dr["tot"]);
        }
        dr.Close();
        sqlcon.Close();
    }
    //public void GetPostRefNo()
    //{
    //    string PosRef;
    //    sqlcon = new SqlConnection(Conn);
    //    sqlcon.Open();
    //    SqlCommand cmd = new SqlCommand("SELECT TOP 1 Post_ref_no FROM [PostDetails] ORDER BY Post_id DESC", sqlcon);
    //    SqlDataReader dr;
    //    dr = cmd.ExecuteReader();
    //    while (dr.Read())
    //    {
    //        PosRef = dr["Post_ref_no"].ToString();
    //        results = PosRef.Substring(PosRef.LastIndexOf('/') + 1);
    //    }
    //    dr.Close();
    //    sqlcon.Close();        
    //}

    protected void LoadBranch_advertised_post()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT branch_id, branch_name from branch");
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlBranch_advertised_post.DataSource = dataTable;
            this.ddlBranch_advertised_post.DataTextField = "branch_name";
            this.ddlBranch_advertised_post.DataValueField = "branch_id";
            this.ddlBranch_advertised_post.DataBind();
            this.ddlBranch_advertised_post.Items.Insert(0, "Select One...");

            sqlcon.Close();
        }
    }
    protected void LoadChief_Directorate(int branch_id)
    {
        SqlCommand cmd = new SqlCommand("SELECT Chief_Dire_id,Chief_Dire_Name from Chief_Directorate where Branch_ID = @Brach_id ORDER BY Chief_Dire_Name ASC ");
        cmd.Parameters.AddWithValue("@Brach_id", branch_id);
        //this.sqlcon.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlChief_Directorate_advertised_post.DataSource = dataTable;
            this.ddlChief_Directorate_advertised_post.DataTextField = "Chief_Dire_Name";
            this.ddlChief_Directorate_advertised_post.DataValueField = "Chief_Dire_id";
            this.ddlChief_Directorate_advertised_post.DataBind();
            this.ddlChief_Directorate_advertised_post.Items.Insert(0, "Select One...");
            sqlcon.Close();
        }
    }
    protected void LoadDirectorate(int Chief_Dire_id)
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Directorate_id,Directorate_Name from Directorates where  Chief_Dire_ID = @Chief_Dire_id ORDER BY Directorate_Name ASC");
        selectCommand.Parameters.AddWithValue("@Chief_Dire_id", Chief_Dire_id);
        //this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDirectorate_advertised_post.DataSource = dataTable;
            this.ddlDirectorate_advertised_post.DataTextField = "Directorate_Name";
            this.ddlDirectorate_advertised_post.DataValueField = "Directorate_id";
            this.ddlDirectorate_advertised_post.DataBind();
            this.ddlDirectorate_advertised_post.Items.Insert(0, "Select One...");

            sqlcon.Close();
        }
    }
    protected void LoadSub_Directorate(int Directorate_id)
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Sub_Directorate_id ,Sub_Directorate_Name from Sub_Directorates where Directorate_ID= @Directorate_ID  ORDER BY Sub_Directorate_Name ASC");
        selectCommand.Parameters.AddWithValue("@Directorate_id", Directorate_id);
        //this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            ddlComponet_advertised_post.Items.Clear();

            this.ddlComponet_advertised_post.DataSource = dataTable;
            this.ddlComponet_advertised_post.DataTextField = "Sub_Directorate_Name";
            this.ddlComponet_advertised_post.DataValueField = "Sub_Directorate_id";
            this.ddlComponet_advertised_post.DataBind();
            this.ddlComponet_advertised_post.Items.Insert(0, "Select One...");
        }
        else if (dataTable.Rows.Count == 0)
        {
            ddlComponet_advertised_post.Items.Clear();

            ddlComponet_advertised_post.Enabled = false;
            ddlComponet_advertised_post.DataTextField = "N/A";
            ddlComponet_advertised_post.DataValueField = "N/A";
            this.ddlComponet_advertised_post.DataBind();
            this.ddlComponet_advertised_post.Items.Insert(0, "N/A");

        }
        sqlcon.Close();
    }

    public void CheckIfPostExists()
    {
        if (txtPostRefNo.Enabled == true)
        {
            string PostRef = txtPostRefNo.Text;

            bool exists = false;


            using (SqlCommand cmd2 = new SqlCommand("select count(*) from PostDetails where Post_ref_no = '" + PostRef + "' "))
            {
                cmd2.Parameters.AddWithValue("Post_ref_no", PostRef);
                //this.sqlcon.ConnectionString = this.Conn;
                cmd2.Connection = this.sqlcon;

                sqlcon.Open();
                exists = (int)cmd2.ExecuteScalar() > 0;
                sqlcon.Close();
            }
            if (exists)
            {

                Message("This Post already exists");
                txtPostRefNo.Focus();
                return;
            }
        }

        //sqlcon.Close();
    }
    public void MessageValidate(string message)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("<script type = 'text/javascript'>");
        sb.Append("window.onload=function(){");
        sb.Append("alert('");
        sb.Append(message);
        sb.Append("')};");
        sb.Append("</script>");
        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //ClientScript.RegisterStartupScript(Page.GetType(), "key", "alert('Button Clicked')", true);
        ValiadateControls();
        CheckIfPostExists();
        try
        
        {
            if (Convert.ToDateTime(dpPostDateAdvertised.Text) < Convert.ToDateTime(dpPostDateCreated.Text))
            {
                MessageValidate("Date Post Advertised Cannot be less than Date Post Created.");
                return;
            }
            string agency = "";

            foreach (ListItem item in ListBox1.Items)
            {
                if (item.Selected)
                {
                    agency += item.Text + ",";

                }

            }


            SqlCommand cmd = new SqlCommand();
            //sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;


            cmd.CommandText = "insertPostDetails";
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.Add("@Branch_advertised_post", SqlDbType.VarChar).Value = ddlBranch_advertised_post.SelectedItem.Text;


            cmd.Parameters.Add("@Chief_Directorate_advertised_post", SqlDbType.VarChar).Value = ddlChief_Directorate_advertised_post.SelectedItem.Text;

            if (ddlDirectorate_advertised_post.SelectedItem.Text == "" || ddlDirectorate_advertised_post.Enabled == false)
            {
                cmd.Parameters.Add("@Directorate_advertised_post", SqlDbType.VarChar).Value = "";
            }
            {
                cmd.Parameters.Add("@Directorate_advertised_post", SqlDbType.VarChar).Value = ddlDirectorate_advertised_post.SelectedItem.Text;
            }

            if (ddlComponet_advertised_post.DataTextField == "N/A" || ddlComponet_advertised_post.Enabled == false)
            {
                cmd.Parameters.Add("@Sub_Directorate", SqlDbType.VarChar).Value = "";
            }
            else
            {
                cmd.Parameters.Add("@Sub_Directorate", SqlDbType.VarChar).Value = ddlComponet_advertised_post.SelectedItem.Text;
            }

            cmd.Parameters.Add("@post_applied", SqlDbType.VarChar).Value = txtPostApplied.Text;

            cmd.Parameters.Add("@Post_ref_no", SqlDbType.VarChar).Value = txtPostRefNo.Text;

            if (ddlPostLevel.Enabled == false && ddlOSD.SelectedItem.Text == "OSD")
            {
                cmd.Parameters.Add("@Post_Level", SqlDbType.VarChar).Value = ddlOSDPost_grade.SelectedItem.Text;
            }
            else
            {
                cmd.Parameters.Add("@Post_Level", SqlDbType.VarChar).Value = ddlPostLevel.Text;
            }
            cmd.Parameters.Add("@vacant_filled", SqlDbType.VarChar).Value = ddlVacantorFilled.Text;
            cmd.Parameters.Add("@Post_Salary_Notch", SqlDbType.Decimal).Value = Convert.ToDecimal(txtPostSalaryNotch.Text);
            cmd.Parameters.Add("@post_date_advertised", SqlDbType.DateTime).Value = dpPostDateAdvertised.Text;
            cmd.Parameters.Add("@post_closing_date", SqlDbType.DateTime).Value = dpPostClosingDate.Text;

            cmd.Parameters.Add("@media_public_date", SqlDbType.DateTime).Value = dpMediaPublicDate.Text;

            cmd.Parameters.Add("@advertising_agency", SqlDbType.VarChar).Value = agency.TrimEnd(',');

            cmd.Parameters.Add("@cost_of_advert", SqlDbType.VarChar).Value = txtCostOfAdvert.Text;

            cmd.Parameters.Add("@response_handling", SqlDbType.VarChar).Value = ddlResponse.SelectedItem.Text;
            cmd.Parameters.Add("@OSD_or_non_OSD", SqlDbType.VarChar).Value = ddlOSD.SelectedValue;
            //cmd.Parameters.Add("@no_cv_released", SqlDbType.VarChar).Value = txtNoOfCvReleased.Text;

            //cmd.Parameters.Add("@date_cv_released", SqlDbType.DateTime).Value = dpDateCvReleased.Text;

            cmd.Parameters.Add("@Date_captured", SqlDbType.DateTime).Value = DateTime.Today;

            if (ddlComponet_advertised_post.DataTextField == "N/A")
            {

                cmd.Parameters.Add("@Sub_Directorate_id", SqlDbType.Int).Value = DBNull.Value;
            }
            else
            {
                cmd.Parameters.Add("@Sub_Directorate_id", SqlDbType.Int).Value = ddlComponet_advertised_post.SelectedValue;
            }
            cmd.Parameters.Add("@Captured_by", SqlDbType.VarChar).Value = Session["name"].ToString() + " " + Session["surname"].ToString();

            cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = txtComments.Text;
            cmd.Parameters.Add("@date_post_created", SqlDbType.DateTime).Value = dpPostDateCreated.Text;
            cmd.Parameters.Add("@InternalOrExternal", SqlDbType.VarChar).Value = ddlExtOrInt.SelectedValue;
            cmd.Parameters.Add("@Component", SqlDbType.VarChar).Value = txtComponent.Text;
            if (ddlOSD.SelectedItem.Text == "OSD")
            {
                cmd.Parameters.Add("@OSD_Category", SqlDbType.VarChar).Value = ddlOSDCategory.SelectedItem.Text;
            }
            else if (ddlOSD.SelectedItem.Text == "Non-OSD")
            {
                cmd.Parameters.Add("@OSD_Category", SqlDbType.VarChar).Value = DBNull.Value;
            }
            try
            {
                cmd.Parameters.Add("@no_of_posts", SqlDbType.Int).Value = Convert.ToInt32(txtNoOfPosts.Text);
            }
            catch
            {
                Message("Number of posts must be a whole number");
            }
            sqlcon.Open();
            cmd.ExecuteNonQuery();
            sqlcon.Close();
            ShowMessage("Post details successfully captured");
        }
        catch
        {


        }
    }

    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Post Details successfully captured');window.location.href='Home.aspx';('" + message + "')</script>");

    }

    public void generateRef(int tot)
    {
        try
        {

            SqlCommand cmd = new SqlCommand("select abbreviation from Directorates where Directorate_Name = '" + ddlDirectorate_advertised_post.SelectedItem.Text + "'", sqlcon3);

            this.sqlcon3.ConnectionString = this.Conn;
            cmd.Connection = this.sqlcon3;
            sqlcon3.Open();

            SqlDataReader dr;

            dr = cmd.ExecuteReader();


            while (dr.Read())
            {
                string name = dr["abbreviation"].ToString();
                string refNo;

                if (count > 0 && count < 9)
                {
                    int j = count + 1;

                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + "0" + j.ToString();
                    //HiddenField1.Value = refNo;
                    txtPostRefNo.Text = refNo;
                }
                else if (count >= 9)
                {
                    int j = count + 1;

                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + j.ToString();
                    //HiddenField1.Value = refNo;
                    txtPostRefNo.Text = refNo;

                }
                else if (count == 0)
                {
                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + "01";
                    //HiddenField1.Value = refNo;
                    txtPostRefNo.Text = refNo;
                }

            }
        }
        catch
        {

        }

        sqlcon3.Close();
    }


    protected void ddlBranch_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlBranch_advertised_post.SelectedIndex != 0)
        {
            ddlChief_Directorate_advertised_post.Items.Clear();
            ddlChief_Directorate_advertised_post.Enabled = true;
            ddlDirectorate_advertised_post.Items.Clear();
            this.LoadChief_Directorate(Convert.ToInt32(ddlBranch_advertised_post.SelectedValue));
            ddlChief_Directorate_advertised_post.Enabled = true;
            ddlDirectorate_advertised_post.Enabled = false;
            ddlComponet_advertised_post.Items.Clear();
            ddlComponet_advertised_post.Enabled = false;

            txtPostRefNo.Text = string.Empty;
            //ddlOSD.SelectedIndex = 0;
            ddlExtOrInt.SelectedIndex = 0;
        }
        else
        {
            //ddlChief_Directorate_advertised_post.Items.Clear();
            ddlChief_Directorate_advertised_post.Enabled = false;
            ddlDirectorate_advertised_post.Enabled = false;
            ddlComponet_advertised_post.Enabled = false;


            Message("Please select Branch");
        }
    }
    protected void ddlChief_Directorate_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlChief_Directorate_advertised_post.SelectedIndex != 0)
        {
            this.LoadDirectorate(Convert.ToInt32(ddlChief_Directorate_advertised_post.SelectedValue));
            ddlDirectorate_advertised_post.Enabled = true;
            ddlComponet_advertised_post.Enabled = false;

            txtPostRefNo.Text = string.Empty;
            //ddlOSD.SelectedIndex = 0;
            ddlExtOrInt.SelectedIndex = 0;
        }
        else if (ddlBranch_advertised_post.Text == "Select One...")
        {

            Message("Please select Branch");
        }
        else
        {
            ddlComponet_advertised_post.Enabled = false;
            ddlDirectorate_advertised_post.Enabled = false;


            Message("Please select Chief Directorate");
        }
    }
    protected void ddlDirectorate_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDirectorate_advertised_post.SelectedIndex != 0)
        {
            this.LoadSub_Directorate(Convert.ToInt32(ddlDirectorate_advertised_post.SelectedValue));
            ddlComponet_advertised_post.Enabled = true;

            txtPostRefNo.Text = string.Empty;
            //ddlOSD.SelectedIndex = 0;
            ddlExtOrInt.SelectedIndex = 0;
        }
        else if (ddlChief_Directorate_advertised_post.Text == "Select One...")
        {
            ddlDirectorate_advertised_post.Enabled = false;
            ddlChief_Directorate_advertised_post.Enabled = false;
            ddlComponet_advertised_post.Enabled = false;

            Message("Please select Chief Directorate");
        }
        else
        {
            ddlComponet_advertised_post.Enabled = false;

            Message("Please select Directorate");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void ddlExtOrInt_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExtOrInt.SelectedValue == "Internal")
        {
            txtPostRefNo.Enabled = false;

            if (ddlBranch_advertised_post.Enabled == false)
            {
                Message("Please select Directorate");
            }
            else
            {
                generateRef(count);
            }
        }
        else if (ddlExtOrInt.SelectedValue == "External")
        {
            txtPostRefNo.Enabled = true;
            txtPostRefNo.Text = string.Empty;
            txtPostRefNo.Focus();
        }
        else
        {

            Message("Please specify if post is Internal or External");
        }



    }
    protected void ddlVacantorFilled_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlVacantorFilled.SelectedValue == "Vacant")
        {
            txtComments.Visible = false;
            lblComments.Visible = false;
        }
        else if (ddlVacantorFilled.SelectedValue == "Filled")
        {
            lblComments.Visible = true;
            txtComments.Visible = true;
        }
    }
    public void LoadAgencies()
    {
        SqlCommand Command = new SqlCommand("SELECT * from advertising_agency");
        this.sqlcon2.ConnectionString = this.Conn;
        Command.Connection = this.sqlcon2;
        SqlDataAdapter adapter = new SqlDataAdapter(Command);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ListBox1.DataSource = dataTable;
            this.ListBox1.DataTextField = "advertising_agency_name";
            this.ListBox1.DataValueField = "advertising_agency_id";
            this.ListBox1.DataBind();

        }
    }
    protected void ddlComponet_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlComponet_advertised_post.SelectedIndex == 0)
        {

            Message("Please select Sub-Directorate/Component!!!!");
        }
        else
        {
            txtPostRefNo.Text = string.Empty;
            //ddlOSD.SelectedIndex = 0;
            ddlExtOrInt.SelectedIndex = 0;
        }
    }
    protected void txtPostSalaryNotch_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtCostOfAdvert_TextChanged(object sender, EventArgs e)
    {
        if (txtCostOfAdvert.Text != "")
        {
            try
            {

                decimal iCost = Convert.ToDecimal(txtCostOfAdvert.Text);

                string sCost = iCost.ToString("#,##0.00");
                txtCostOfAdvert.Text = sCost.ToString();
            }
            catch
            {
                Message("Please enter a valid money");
                txtCostOfAdvert.Text = string.Empty;
                txtCostOfAdvert.Focus();
            }
        }
    }
    protected void ddlPostLevel_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSD.SelectedIndex != 0)
        {
            NonOSDsalaryNotch();
        }
        else
        {

            Message("Please Specify if Post is OSD or Non-OSD");
        }
    }
    public void NonOSDsalaryNotch()
    {
        try
        {
            sqlcon4 = new SqlConnection(Conn);
            String sql = "Select * from salary_scale where post_level = '" + ddlPostLevel.SelectedValue + "' ";
            sqlcon4.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon4);
            SqlDataReader dr = sqlcmd.ExecuteReader();


            while (dr.Read())
            {

                decimal salary = Convert.ToDecimal(dr["non-OSD_salary_notch"]);
                txtPostSalaryNotch.Text = salary.ToString("#,##0.00");


            }
            sqlcon4.Close();

            ddlOSDPost_grade.SelectedIndex = 0;
            ddlOSDCategory.SelectedIndex = 0;
        }
        catch
        {

        }
    }


    public void LoadOSDcategory()
    {
        SqlCommand selectCommand = new SqlCommand("select * from OSD_categories");
        this.sqlcon4.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlOSDCategory.DataSource = dataTable;
            this.ddlOSDCategory.DataTextField = "category_name";
            this.ddlOSDCategory.DataValueField = "category_id";
            this.ddlOSDCategory.DataBind();
            this.ddlOSDCategory.Items.Insert(0, "Select One...");

        }
        sqlcon4.Close();
    }

    public void LoadOSDpost_grade()
    {
        SqlCommand cmd = new SqlCommand("select * from [dbo].[OSD_posts_and_grades] where category_id = '" + ddlOSDCategory.SelectedValue + "'");
        this.sqlcon4.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlOSDPost_grade.DataSource = dataTable;
            this.ddlOSDPost_grade.DataTextField = "OSD_post_name";
            this.ddlOSDPost_grade.DataValueField = "OSD_post_id";
            this.ddlOSDPost_grade.DataBind();
            this.ddlOSDPost_grade.Items.Insert(0, "Select One...");
        }
        sqlcon4.Close();
    }
    public void LoadNoneOSDPostLevels()
    {
        SqlCommand selectCommand = new SqlCommand("select * from salary_scale");
        this.sqlcon4.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlPostLevel.DataSource = dataTable;
            this.ddlPostLevel.DataTextField = "post_level";
            this.ddlPostLevel.DataValueField = "post_level";
            this.ddlPostLevel.DataBind();
            this.ddlPostLevel.Items.Insert(0, "Select One...");

        }
        sqlcon4.Close();
    }

    public void OSDsalaryNotch()
    {
        try
        {
            sqlcon4 = new SqlConnection(Conn);
            String sql = "Select OSD_salary_notch from [dbo].[OSD_posts_and_grades] where category_id = '" + ddlOSDCategory.SelectedValue + "' and OSD_post_id = '" + ddlOSDPost_grade.SelectedValue + "' ";
            sqlcon4.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon4);
            SqlDataReader dr = sqlcmd.ExecuteReader();

            while (dr.Read())
            {
                decimal salary = Convert.ToDecimal(dr["OSD_salary_notch"]);
                txtPostSalaryNotch.Text = salary.ToString("#,##0.00");
            }
            sqlcon4.Close();

            ddlPostLevel.SelectedIndex = 0;

        }
        catch
        {

        }


    }
    protected void ddlOSD_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSD.SelectedValue == "Non-OSD")
        {
            ddlOSDCategory.Items.Clear();
            ddlOSDPost_grade.Items.Clear();

            ddlOSDCategory.Enabled = false;
            ddlOSDPost_grade.Enabled = false;



            ddlPostLevel.Enabled = true;

            txtPostSalaryNotch.Text = string.Empty;

            LoadNoneOSDPostLevels();


        }
        else if (ddlOSD.SelectedValue == "OSD")
        {
            ddlPostLevel.Enabled = false;

            ddlOSDCategory.Enabled = true;
            ddlOSDPost_grade.Enabled = true;


            ddlPostLevel.Items.Clear();
            txtPostSalaryNotch.Text = string.Empty;

            LoadOSDcategory();
        }
        else
        {

            Message("Please Specify if Post is OSD or Non-OSD");

            ddlPostLevel.SelectedIndex = 0;
        }
    }
    protected void ddlOSDCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSD.SelectedIndex != 0)
        {
            if (ddlOSDCategory.SelectedIndex != 0)
            {
                LoadOSDpost_grade();
            }
            else
            {

                Message("Please Select OSD Category");
            }
        }

        else
        {

            Message("Please Specify if Post is OSD or Non-OSD");
        }
    }
    protected void ddlOSDPost_grade_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSDPost_grade.SelectedIndex != 0)
        {
            if (ddlOSDCategory.SelectedIndex != 0)
            {
                OSDsalaryNotch();
            }
            else
            {
                Message("Please select OSD Category");
            }
        }
        else
        {

            Message("Please select OSD Post/Grade");
        }

    }
    public void ValiadateControls()
    {       
        
    }
    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                   "alert('" + msg + "');", true);
    }

protected void RangeValidator_Init(object sender, EventArgs e)
{
    ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();

    
}

protected void txtComponent_TextChanged(object sender, EventArgs e)
{
    if (txtComponent.Text == "")
    {
        Message("Please enter component number!");
    }
}
}