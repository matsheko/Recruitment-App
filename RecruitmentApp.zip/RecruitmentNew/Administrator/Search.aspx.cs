﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Default2 : System.Web.UI.Page
{
    String strcon = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {           
            txtRef.Focus();
            txtID.Enabled = false;
            txtPassport.Enabled = false;
        }
        if (Session.Count != 0)
        {
            string t = Session["PageName"].ToString();
            //Label1.Text = t;


            if (t == "Add Candidates Details" || t == "Edit Post Details" || t == "Capture Interview Details" || t == "Capture shortlisting Details" || t == "Edit shortlisting Details")
            {
                lblIDNumber.Visible = false;
                txtID.Visible = false;
                rbtnID.Visible = false;

                lblPassport.Visible = false;
                txtPassport.Visible = false;
                rbtnPassport.Visible = false;
                btnSearchID.Visible = false;
                btnSearch.Visible = true;

            }
            else if (t == "Edit Candidates Details" || t == "Edit Interview Details" )
            {
                lblIDNumber.Enabled = true;
                //txtID.Enabled = true;
                btnSearchID.Visible = true;
                btnSearch.Visible = false;
            }
        }
        else if (Session.Count == 0)
        {
            Response.Redirect("../session.aspx");
        }
        
    }
    public void HideIDorPassport()
    {
        string t = Session["PageName"].ToString();
        if (Session["selectedPage"] != null)
            if (t == "Edit Candidates Details" || t == "Edit shortlisting Details" || t == "Edit Interview Details")
            {
                lblIDNumber.Visible = true;
                txtID.Visible = true;

                rbtnID.Visible = false;
                rbtnPassport.Visible = false;
                lblPassport.Visible = false;
                txtPassport.Visible = false;
                btnSearchID.Visible = true;
                btnSearch.Visible = false;
            }
            else
            {
                lblIDNumber.Visible = false;
                txtID.Visible = false;

                rbtnID.Visible = false;
                rbtnPassport.Visible = false;
                lblPassport.Visible = false;
                txtPassport.Visible = false;
                btnSearchID.Visible = false;
                btnSearch.Visible = true;
            }

    }

    protected void txtID_TextChanged(object sender, EventArgs e)
    {
       
    }
    protected void rbtnID_CheckedChanged(object sender, EventArgs e)
    {
        txtPassport.Enabled = false;
        txtID.Enabled = true;
        txtID.Focus();
    }
    protected void rbtnPassport_CheckedChanged(object sender, EventArgs e)
    {
        txtID.Enabled = false;
        txtPassport.Enabled = true;
        txtPassport.Focus();
    }
    protected void btnSearchID_Click(object sender, EventArgs e)
    {
        search_By_ID_and_ReferenceNo();
    }
     protected void btnSearch_Click(object sender, EventArgs e)
    {
        searchByReference();
    }
    //public void Message(String msg)
    //{
    //    Response.Write("<script language = javascript>alert('" + msg + "')</script>");
    //}

    public void Message(string msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + msg + "');", true);
    }
    public void searchByReference()
    {
        string refnumber = txtRef.Text;
        if (txtRef.Text == "")
        {
            Message("Please enter reference number.");
           
            txtRef.Focus();
        }

        else if (txtRef.Text != "")
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = strcon;
            cmd.Connection = sqlcon;
            sqlcon.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SearchbyRef";

            cmd.Parameters.AddWithValue("@Post_ref_no", txtRef.Text);

            SqlDataReader sqldr = cmd.ExecuteReader();

            if (sqldr.Read())
            {

                string t = Session["PageName"].ToString();

                if (t != null)
                {
                    if (t == "Add Candidates Details")
                    {
                        Response.Redirect("CaptureApplicantDetails.aspx?id=" + this.txtRef.Text);
                    }
                    else if (t == "Capture shortlisting Details")
                    {
                        Response.Redirect("CaptureShortlistingDetails.aspx?id=" + this.txtRef.Text);
                    }

                    else if (t == "Capture Interview Details")
                    {
                        Response.Redirect("CaptureInterviewDetails.aspx?id=" + this.txtRef.Text);
                    }
                    else if (t == "Edit Post Details")
                    {
                        Response.Redirect("UpdatePostDetails.aspx?id=" + this.txtRef.Text);
                    }
                    else if (t == "Edit shortlisting Details")
                    {
                        Response.Redirect("UpdateShortlistingDetails.aspx?id=" + this.txtRef.Text);
                    }
                }
                sqlcon.Close();
            }
            else
            {                
                Message("Post reference number does not exist.");
                sqlcon.Close();
            }

        }
    }

    public void search_By_ID_and_ReferenceNo()
    {
        string refnumber = txtRef.Text;
        string Id = txtID.Text, Passport = txtPassport.Text;
        if (txtRef.Text == "")// && txtID.Text == "")
        {
            Message("Please enter reference number.");
            txtRef.Focus();
            return;
        }
        else if (rbtnID.Checked == false && rbtnPassport.Checked == false) 
        {
            Message("Please choose id number or passport number.");
            return;
        }
        if (txtID.Text == "" && txtID.Enabled == true)
        {
            Message("Please enter id number.");
            return;
        }
        if (txtPassport.Text == "" && txtPassport.Enabled == true)
        {
            Message("Please enter passport number.");
            return;
        }
        else if (txtID.Text == string.Empty && txtRef.Text != string.Empty && txtID.Enabled==true) 
        {
            Message("Please enter id number.");
            txtID.Focus();
            return;
        }
        else if (txtRef.Text != "" && txtPassport.Text == "" && txtPassport.Enabled==true)
        {
            Message("Please enter passport number.");
            txtPassport.Focus();
            return;
        }
        else if (refnumber != "" && Id != "")
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = strcon;
            cmd.Connection = sqlcon;

            sqlcon.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SearchbyRefandID";

            cmd.Parameters.AddWithValue("@post_reference", txtRef.Text.ToString());
            cmd.Parameters.AddWithValue("@idNo", txtID.Text.ToString());

            SqlDataReader sqldr = cmd.ExecuteReader();

            if (sqldr.Read())
            {
                string t = Session["PageName"].ToString();

                //String navigatePage = Application["PageName"].ToString();
                if (t != null)
                {
                    if (t == "Edit Candidates Details")
                    {
                        Response.Redirect("UpdateApplicantDetails.aspx?id=" + this.txtID.Text + "&Ref=" + this.txtRef.Text);
                    }
                    //else if (t == "Edit shortlisting Details")
                    //{
                    //    Response.Redirect("UpdateShortlistingDetails.aspx?id=" + this.txtID.Text + "&Ref=" + this.txtRef.Text);
                    //}

                    else if (t == "Edit Interview Details")
                    {
                        Response.Redirect("UpdateInterviewDetails.aspx?id=" + this.txtID.Text + "&Ref=" + this.txtRef.Text);
                    }
                }

            }
            else
            {
                Message("no record found");
               
                txtRef.Focus();
            }
            sqlcon.Close();
        }
        else if (Passport != "" && refnumber != "")
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = strcon;
            cmd.Connection = sqlcon;

            sqlcon.Open();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "SearchbyRefandPassport";

            cmd.Parameters.AddWithValue("@post_reference", txtRef.Text.ToString());
            cmd.Parameters.AddWithValue("@Passport", txtPassport.Text.ToString());

            SqlDataReader sqldr = cmd.ExecuteReader();

            if (sqldr.Read())
            {
                string t = Session["PageName"].ToString();

                if (t != null)
                {
                    if (t == "Edit Candidates Details")
                    {
                        Response.Redirect("UpdateApplicantDetails.aspx?id=" + this.txtPassport.Text + "&Ref=" + this.txtRef.Text);
                    }
                    //else if (t == "Edit shortlisting Details")
                    //{
                    //    Response.Redirect("UpdateShortlistingCommiteeDetails.aspx?id=" + this.txtPassport.Text + "&Ref=" + this.txtRef.Text);
                    //}

                    else if (t == "Edit Interview Details")
                    {
                        Response.Redirect("UpdateInterviewDetails.aspx?id=" + this.txtPassport.Text + "&Ref=" + this.txtRef.Text);
                    }
                }

            }
            else
            {
                Message("no record found");
               
                txtRef.Focus();
            }
            sqlcon.Close();
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void txtPassport_TextChanged(object sender, EventArgs e)
    {

    }
}