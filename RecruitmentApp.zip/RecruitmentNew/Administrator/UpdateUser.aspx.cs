﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            try
            {

                SqlCommand cmd = new SqlCommand(Conn);
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                sqlcon.Open();
                cmd.CommandText = "SearchbyID";
                cmd.CommandType = CommandType.StoredProcedure;

                

                cmd.Parameters.AddWithValue("@userID", Request["id"]);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    txtName.Text = dr["name"].ToString();
                    txtPersal.Text = dr["persal"].ToString();
                    txtSurname.Text = dr["surname"].ToString();
                    txtUsername.Enabled = false;
                    txtUsername.Text = dr["username"].ToString();
                    ddlRole.SelectedItem.Text = dr["role"].ToString();
                    txtEmail.Text = dr["email"].ToString();
                   
                }

            }
            catch
            {

            }
        }
      }
    
    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        SqlCommand cmd = new SqlCommand(Conn);
        sqlcon.ConnectionString = Conn;
        cmd.Connection = sqlcon;

        cmd.CommandText = "UpdateUser";
        cmd.Parameters.AddWithValue("@userID", Request["id"]);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = txtName.Text;
        cmd.Parameters.Add("@persal", SqlDbType.VarChar).Value = txtPersal.Text;
        cmd.Parameters.Add("@surname", SqlDbType.VarChar).Value = txtSurname.Text;
        cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = txtUsername.Text;
        cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtPassword.Text;
        cmd.Parameters.Add("@role", SqlDbType.VarChar).Value = ddlRole.SelectedItem.Text;
        cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = txtEmail.Text;

        sqlcon.Open();
        cmd.ExecuteNonQuery();
        sqlcon.Close();

        ShowMessage("User details successfully updated.");

    }

    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('User details successfully updated.');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}