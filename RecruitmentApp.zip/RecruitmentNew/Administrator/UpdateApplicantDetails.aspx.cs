﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {

        Page.MaintainScrollPositionOnPostBack = true;
        string id = Request["id"].ToString(), referencenum = Request["Ref"].ToString();
        Label1.Text = referencenum;
        txtInitials.Focus();
        if (!IsPostBack)
        {
            
            LoadFieldOfStudy();
            sqlcon = new SqlConnection(Conn);
            String sql = "Select * from Applicants where post_reference = '" + Request["Ref"].ToString() + "' and (idno ='" + Request["id"].ToString() + "'or Passport ='" + Request["id"].ToString() + "')";
            sqlcon.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
            SqlDataReader dr = sqlcmd.ExecuteReader();

            while (dr.Read())
            {

                string applicantID = dr["applicant_id"].ToString();
                Session["applicant_id"] = applicantID;

                txtInitials.Text = dr["initials"].ToString();
                txtName.Text = dr["full_names"].ToString();
                txtSurname.Text = dr["Surname"].ToString();
                txtID.Text = dr["idNo"].ToString();
                txtPassport.Text = dr["passport"].ToString();
                txtAge.Text = dr["age"].ToString();
                ddlGender.Text = dr["gender"].ToString();
                ddlDisability.SelectedValue = dr["disability"].ToString();
                txtSpecifyDisability.Text = dr["specify_disability"].ToString();
                ddlRace.SelectedValue = dr["race"].ToString();
                txtIntorExtPost.Text = dr["internal_external_post"].ToString();
                ddlWorkExperience.SelectedItem.Text = dr["working_experience"].ToString();
                ddlRelatedExperience.SelectedItem.Text = dr["related_experience"].ToString();
                Label1.Text = dr["field_of_study"].ToString();
                txtTypeOfQuali.Text = dr["type_of_qualification"].ToString();
                ddlAdditionalQual.SelectedValue = dr["additional_qualification"].ToString();
                //txtListQualification.Text = dr["list_qualification"].ToString();
                txtInstitution.Text = dr["institution"].ToString();
                txtCell.Text = dr["cell_phone"].ToString();
                txtOtherNumber.Text = dr["other_number"].ToString();
                ddlCountry.SelectedItem.Text = dr["citizenship"].ToString();

                ddlRecommend.SelectedValue = dr["recommend"].ToString();
                txtComments.Text = dr["comments"].ToString();
               
                dpPermitExpDate.Text = dr["work_permit_exp_date"].ToString();           
                txtPermit.Text = dr["work_permit"].ToString();

                if (ddlCountry.SelectedItem.Text == "South Africa")
                {
                    txtPassport.Enabled = false;
                    dpPermitExpDate.Enabled = false;
                    FileUpload1.Enabled = false;
                    RadioButtonList1.SelectedValue = "South African";
                }
                else
                {
                    txtPassport.Enabled = true;
                    dpPermitExpDate.Enabled = true;
                    FileUpload1.Enabled = true;
                    RadioButtonList1.SelectedValue = "Non-South African";
                }

                if (txtID.Text != "")
                {
                    txtPassport.Enabled = false;
                }
                else if (txtPassport.Text != "")
                {
                    txtID.Enabled = false;
                }

                if (ddlCountry.SelectedItem.Text == "South Africa")
                {
                    txtAge.Enabled = false;
                }
            }
            sqlcon.Close();
            ddlQualification.Visible = false;
            ddlFieldOfStudy.SelectedItem.Text = Label1.Text;          

            bindGriview();
            
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        validate_fields();
        updateBy_iD_Number();
    }
    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Applicant details updated successfully.');window.location.href='Home.aspx';('" + message + "')</script>");
    }
    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                   "alert(' " + msg + "');", true);
    }
    public void calculateAge()
    {
        #region generating age and specifying gender from id number

        if (this.txtID.Text == "")
        {
            Message("Please enter the ID number");
            this.txtID.Focus();
        }
        else if (this.txtID.Text.Length != 13)
        {
            Message("South African ID must be 13 digits....");
            this.txtID.Focus();
        }
        else
        {

            int century = 1900, birthyear, age, today = DateTime.Today.Year, actualAge, gender;
            birthyear = century + int.Parse(txtID.Text.Substring(0, 2));
            gender = int.Parse(txtID.Text.Substring(6, 1));

            //G : Gender. 0-4 Female; 5-9 Male
            if (gender <= 4)
            {
                ddlGender.SelectedValue = "Female";
            }
            else
            {
                ddlGender.SelectedValue = "Male";
            }
            age = today - birthyear;

            if (age >= 100)
            {
                actualAge = age - 100;
                txtAge.Text = actualAge.ToString();
            }

            else
            {
                txtAge.Text = age.ToString();
            }


        }
        #endregion
    }
    protected void txtIDPassport_TextChanged(object sender, EventArgs e)
    {
        calculateAge();
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedValue == "Select Country")
        {
            Message("Please select country.");
        }
        else if (ddlCountry.SelectedValue == "ZA")
        {
            txtID.Enabled = true;
            txtID.Focus();
            txtPassport.Enabled = false;
            txtPassport.Text = string.Empty;
            txtAge.Text = string.Empty;
            txtAge.Enabled = false;
        }
        else
        {
            txtPassport.Enabled = true;
            txtPassport.Focus();
            txtID.Enabled = false;
            txtID.Text = "";
            txtAge.Text = "";
            txtAge.Enabled = true;
        }
    }

    protected void txtName_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtName.Text, @"^[a-zA-Z ]+$"))
        {

            ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert('Firstnames must be alphabets only..');", true);
            txtName.Focus();
        }
        Regex initials = new Regex(@"(\b[a-zA-Z])[a-zA-Z]* ?");
        string init = initials.Replace(txtName.Text, "$1");
        txtInitials.Text = init.ToUpper();
        txtInitials.Enabled = false;
    }
    protected void ddlDisability_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDisability.SelectedIndex == 0)
        {
            Message("Please select disability");
        }
        else if (ddlDisability.SelectedIndex == 1)
        {
            txtSpecifyDisability.Enabled = true;
        }
        else if (ddlDisability.SelectedIndex == 2)
        {
            txtSpecifyDisability.Enabled = false;
        }
    }
    protected void txtSpecifyDisability_TextChanged(object sender, EventArgs e)
    {
        if (ddlDisability.SelectedIndex == 1 && txtSpecifyDisability.Text == null)
        {
            Message("Please specify disability");
        }
    }
    protected void ddlAdditionalQual_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAdditionalQual.SelectedItem.Text == "Yes")
        {
            table1.Visible = true;
        }
        else if (ddlAdditionalQual.SelectedItem.Text == "No")
        {
            table1.Visible = false;
        }
       
    }
    private void updateBy_iD_Number()
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;
            cmd.CommandText = "UpdateApplicantDetails";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@applicant_id", SqlDbType.VarChar).Value = Convert.ToInt32( Session["applicant_id"]);
            cmd.Parameters.Add("@initials", SqlDbType.VarChar).Value = txtInitials.Text;
            cmd.Parameters.Add("@full_names", SqlDbType.VarChar).Value = txtName.Text;
            cmd.Parameters.Add("@Surname", SqlDbType.VarChar).Value = txtSurname.Text;
            cmd.Parameters.Add("@citizenship", SqlDbType.VarChar).Value = ddlCountry.SelectedItem.ToString();

            cmd.Parameters.Add("@idNo", SqlDbType.VarChar).Value = txtID.Text;
            cmd.Parameters.Add("@passport", SqlDbType.VarChar).Value = txtPassport.Text;

            cmd.Parameters.Add("@age", SqlDbType.VarChar).Value = txtAge.Text;
            cmd.Parameters.Add("@gender", SqlDbType.VarChar).Value = ddlGender.Text;
            cmd.Parameters.Add("@disability", SqlDbType.VarChar).Value = ddlDisability.SelectedItem.Text;
            cmd.Parameters.Add("@specify_disability", SqlDbType.VarChar).Value = txtSpecifyDisability.Text;

            if (ddlRace.Visible == false && txtOtherRace.Visible == true)
            {
                if (txtOtherRace.Text != "")
                {
                    cmd.Parameters.Add("@race", SqlDbType.VarChar).Value = txtOtherRace.Text;
                }
                else
                {
                    Message("Please specify your Race");
                }
            }
            else
            {
                cmd.Parameters.Add("@race", SqlDbType.VarChar).Value = ddlRace.SelectedItem.Text;
            }


            cmd.Parameters.Add("@internal_external_post", SqlDbType.VarChar).Value = txtIntorExtPost.Text;

            cmd.Parameters.Add("@working_experience", SqlDbType.VarChar).Value = ddlWorkExperience.SelectedItem.Text;
            cmd.Parameters.Add("@related_experience", SqlDbType.VarChar).Value = ddlRelatedExperience.SelectedItem.Text;
            cmd.Parameters.Add("@field_of_study", SqlDbType.VarChar).Value = ddlFieldOfStudy.SelectedItem.Text;
            if (ddlQualification.Visible == true)
            {
                cmd.Parameters.Add("@type_of_qualification", SqlDbType.VarChar).Value = ddlQualification.SelectedItem.Text;
            }
            else
            {
                cmd.Parameters.Add("@type_of_qualification", SqlDbType.VarChar).Value = txtTypeOfQuali.Text;
            }

            cmd.Parameters.Add("@additional_qualification", SqlDbType.VarChar).Value = ddlAdditionalQual.SelectedItem.Text;
            //cmd.Parameters.Add("@list_qualification", SqlDbType.VarChar).Value = txtListQualification.Text;
            cmd.Parameters.Add("@institution", SqlDbType.VarChar).Value = txtInstitution.Text;
            cmd.Parameters.Add("@cell_phone", SqlDbType.VarChar).Value = txtCell.Text;
            cmd.Parameters.Add("@other_number", SqlDbType.VarChar).Value = txtOtherNumber.Text;
            cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = Request.QueryString["Ref"];
            cmd.Parameters.Add("@recommend", SqlDbType.VarChar).Value = ddlRecommend.SelectedItem.Text;
            cmd.Parameters.Add("@comments", SqlDbType.VarChar).Value = txtComments.Text;

            if (dpPermitExpDate.Enabled == true)
            {
                cmd.Parameters.Add("@work_permit_exp_date", SqlDbType.DateTime).Value = dpPermitExpDate.Text;
            }
            else if (dpPermitExpDate.Enabled == false)
            {
                cmd.Parameters.Add("@work_permit_exp_date", SqlDbType.DateTime).Value = DBNull.Value;
            }

            if (FileUpload1.HasFile)
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);

                FileUpload1.SaveAs(Server.MapPath("Work Permit/" + filename));
                cmd.Parameters.AddWithValue("@work_permit", filename);
                cmd.Parameters.AddWithValue("@work_permit_file_path", "Work Permit/" + filename);

            }
            else
            {
                if (txtPermit.Text == string.Empty)
                {
                    cmd.Parameters.AddWithValue("@work_permit", string.Empty);
                    cmd.Parameters.AddWithValue("@work_permit_file_path", string.Empty);
                }
                else if (txtPermit.Text != string.Empty)
                {
                    cmd.Parameters.AddWithValue("@work_permit", txtPermit.Text);
                    cmd.Parameters.AddWithValue("@work_permit_file_path", "Work Permit/" + txtPermit.Text);
                }

            }

            sqlcon.Open();
            cmd.ExecuteNonQuery();
            sqlcon.Close();

            ShowMessage("Applicant details updated successfully.");
        }
        catch
        {

        }
    }
    public void validate_fields()
    {
        if (txtName.Text == string.Empty)
        {
            Message("Enter the first names.");
            return;
        }
        else if (txtInitials.Text == string.Empty)
        {
            Message("Enter the initials.");
            return;
        }
        else if (txtSurname.Text == string.Empty)
        {
            Message("Enter the surname.");
            return;
        }
        else if (ddlCountry.SelectedItem.Text == "Select Country")
        {
            Message("Select the country.");
            return;
        }
        else if (RadioButtonList1.SelectedValue == "Non-South African" && dpPermitExpDate.Text == string.Empty)
        {
            Message("Please enter work permit expiry date");
            return;
        }
        else if (RadioButtonList1.SelectedValue == "Non-South African" && txtPermit.Text == string.Empty && FileUpload1.HasFile == false)
        {
            Message("Please upload work permit");
            return;
        }
        else if (txtPassport.Text == string.Empty && txtPassport.Enabled == true)
        {
            Message("Enter the passport number.");
            return;
        }
        else if (txtID.Text == string.Empty && txtID.Enabled == true)
        {
            Message("Enter the ID number.");
            return;
        }
        else if (txtAge.Text == string.Empty)
        {
            Message("Enter the Age.");
            return;
        }

        else if (ddlDisability.SelectedItem.Text == "Select One....")
        {
            Message("Select if you have disability.");
            return;
        }
        else if (ddlDisability.SelectedIndex == 1 && txtSpecifyDisability.Text == string.Empty)
        {
            Message("Enter disability field.");
            return;
        }
        else if (ddlRace.SelectedItem.Text == "Select One....")
        {
            Message("Select the race.");
            return;
        }
        else if (ddlWorkExperience.SelectedItem.Text == "Select One....")
        {
            Message("Select the work experience.");
            return;
        }
        else if (ddlRelatedExperience.SelectedItem.Text == "Select One....")
        {
            Message("Select the related experience.");
            return;
        }
        else if (ddlQualification.SelectedIndex == 0)
        {
            Message("Select the type of qualification.");
            return;
        }
        else if (ddlFieldOfStudy.SelectedItem.Text == "Select One...")
        {
            Message("Select the field of study.");
            return;
        }
        else if (ddlAdditionalQual.SelectedItem.Text == "Select One....")
        {
            Message("Select the addidtional qualification field.");
            return;
        }
        //else if (ddlAdditionalQual.SelectedItem.Text== "Yes" && txtListQualification.Text == string.Empty)
        //{
        //    Message("List all the qualifications.");
        //    return;
        //}
        else if (txtInstitution.Text == string.Empty)
        {
            Message("Enter the institution field.");
            return;
        }
        else if (txtCell.Text == string.Empty)
        {
            Message("Enter the cellphone field.");
            return;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void LoadFieldOfStudy()
    {

        SqlCommand selectCommand = new SqlCommand("select * from Field_Of_Study");
        this.sqlcon2.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon2;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlFieldOfStudy.DataSource = dataTable;
            this.ddlFieldOfStudy.DataTextField = "Description";
            this.ddlFieldOfStudy.DataValueField = "id";
            this.ddlFieldOfStudy.DataBind();
            this.ddlFieldOfStudy.Items.Insert(0, "Select One...");

        }
        sqlcon2.Close();
    }
    protected void LoadQualifications(int fieldOfStudyID)
    {
        SqlCommand cmd = new SqlCommand("select * from [dbo].[Qualifications] where Field_Of_Study = '" + ddlFieldOfStudy.SelectedValue + "'");
        //cmd.Parameters.AddWithValue("@id", fieldOfStudyID);
        this.sqlcon2.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon2;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlQualification.DataSource = dataTable;
            this.ddlQualification.DataTextField = "Description";
            this.ddlQualification.DataValueField = "id";
            this.ddlQualification.DataBind();
            this.ddlQualification.Items.Insert(0, "Select One...");
        }
        sqlcon2.Close();
    }
    protected void ddlFieldOfStudy_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (ddlFieldOfStudy.SelectedIndex != 0)
        {
            LoadQualifications(Convert.ToInt32(ddlFieldOfStudy.SelectedValue));
            ddlQualification.Visible = true;
            txtTypeOfQuali.Visible = false;
        }
        else
        {
            Message("Please select the field of study");
        }
    }
    protected void ddlRace_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRace.SelectedItem.Text == "Other")
        {
            txtOtherRace.Visible = true;
            txtOtherRace.Focus();
            ddlRace.Visible = false;
        }
    }

    private void bindGriview()
    {
        
        SqlCommand cmd2 = new SqlCommand("select * from additional_qualifications where post_reference = '" + Request["Ref"].ToString() + "'  and applicant_id = ' " + Session["applicant_id"] + " '");

        this.sqlcon2.ConnectionString = this.Conn;
        cmd2.Connection = this.sqlcon2;

        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);
        GridView1.DataSource = dt2;
        GridView1.DataBind();
        sqlcon2.Close();

        if (ddlAdditionalQual.SelectedItem.Text== "No")
        {
            table1.Visible = false;
        }
    }
    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(Conn);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        return dt;
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bindGriview();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void AddNewRow(object sender, EventArgs e)
    {
        int applicantID = Convert.ToInt32(Session["applicant_id"]);
        string postRef = Request["Ref"].ToString();

        string qualification = ((TextBox)GridView1.FooterRow.FindControl("txtQualification")).Text;
        string institution = ((TextBox)GridView1.FooterRow.FindControl("txtInstitution")).Text;
       
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into additional_qualifications(post_reference,applicant_id, additional_qualification, institution) " + "values(@post_reference,@applicant_id,@additional_qualification, @institution)";

        cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = postRef;
        cmd.Parameters.Add("@applicant_id", SqlDbType.Int).Value = applicantID;
        cmd.Parameters.Add("@additional_qualification", SqlDbType.VarChar).Value = qualification;
        cmd.Parameters.Add("@institution", SqlDbType.VarChar).Value = institution;
        
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }

    protected void DeleteRow(object sender, EventArgs e)
    {
        LinkButton lnkRemove = (LinkButton)sender;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from  additional_qualifications where " + "id=@id";
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = lnkRemove.CommandArgument;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
    protected void EditRow(object sender, GridViewEditEventArgs e)
    {
        
        GridView1.EditIndex = e.NewEditIndex;
        bindGriview();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bindGriview();
    }
    protected void UpdateRow(object sender, GridViewUpdateEventArgs e)
    {

        int id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text);

        string qualification = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtQualification")).Text;
        string institution = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtInstitution")).Text;
        
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "update additional_qualifications set additional_qualification=@additional_qualification,institution=@institution " + "where id=@id";
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
        cmd.Parameters.Add("@additional_qualification", SqlDbType.VarChar).Value = qualification;
        cmd.Parameters.Add("@institution", SqlDbType.VarChar).Value = institution;
       
        GridView1.EditIndex = -1;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
    protected void ddlQualification_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void disableForeignControls()
    {
        FileUpload1.Enabled = false;
        txtPassport.Enabled = false;
        dpPermitExpDate.Enabled = false;
        txtAge.Enabled = false;
        ddlCountry.Items[193].Enabled = true;
        ddlCountry.SelectedIndex = 193;
        ddlCountry.Enabled = false;
        txtID.Enabled = true;

    }
    protected void enableForeignControls()
    {
        FileUpload1.Enabled = true;
        txtPassport.Enabled = true;
        dpPermitExpDate.Enabled = true;
        txtAge.Enabled = true;
        ddlCountry.Enabled = true;
        ddlCountry.SelectedItem.Text = "Select Country";
        //ddlCountry.SelectedIndex = 0;
        ddlCountry.Items[193].Enabled = false;
        txtID.Text = string.Empty;
        txtID.Enabled = false;
        txtAge.Text = string.Empty;

    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedValue == "South African")
        {
            disableForeignControls();
            ddlCountry.SelectedItem.Text = "South Africa";
            txtPermit.Text = string.Empty;
            dpPermitExpDate.Text = string.Empty;
            txtPassport.Text = string.Empty;
            txtID.Focus();
        }
        else
        {
            txtID.Text = string.Empty;
            //txtPassport.Focus();
            enableForeignControls();
        }
    }
    protected void txtAge_TextChanged(object sender, EventArgs e)
    {

    }
}