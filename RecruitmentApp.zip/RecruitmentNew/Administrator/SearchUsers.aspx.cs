﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Administrator_Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {

            bind();
            
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        searchUsers();
    }

    protected void lbtEdit_Command(object sender, CommandEventArgs e)
    {     

         Response.Redirect("updateuser.aspx?ID=" + e.CommandArgument.ToString() + "", true);
              
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bind();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }
    public void bind()
    {
        SqlCommand cmd = new SqlCommand("SELECT * from users");

        this.sqlcon.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon;

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

        sqlcon.Close();
    }
    public void searchUsers()
    {
        try
        {

            if(txtPersal.Text == string.Empty && txtUsername.Text == string.Empty)
            {
                    SqlCommand cmd = new SqlCommand("SELECT * from users");

                    this.sqlcon.ConnectionString = this.Conn;
                    cmd.Connection = this.sqlcon;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();


            }
            else if (txtPersal.Text == "" && txtUsername.Text != "")
            {
                SqlCommand cmd = new SqlCommand(Conn);
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "SearchUserByUsername";
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@persal", SqlDbType.VarChar).Value = txtPersal.Text;
                cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = txtUsername.Text;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();

                if (da.Fill(dt) == 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                           "alert('No users were found');", true);
                }

            }
            else
            {
                SqlCommand cmd = new SqlCommand(Conn);
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "SearchUserByPersalAndUsername";
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@persal", SqlDbType.VarChar).Value = txtPersal.Text;
                cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = txtUsername.Text;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();

                if (da.Fill(dt) == 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                           "alert('No users were found');", true);
                }

            }
        }
        catch
        {

        }

        sqlcon.Close();
    }


    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}