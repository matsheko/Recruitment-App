﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            txtUsername.Enabled = false;
        }
    }
   
    protected void btnSave_Click1(object sender, EventArgs e)
    {

        try
        {

            string UserName = txtUsername.Text;

            bool exists = false;

            // create a command to check if the username exists
            using (SqlCommand cmd2 = new SqlCommand("select count(*) from users where username = '" + UserName + "' "))
            {
                cmd2.Parameters.AddWithValue("Username", UserName);
                this.sqlcon.ConnectionString = this.Conn;
                cmd2.Connection = this.sqlcon;

                sqlcon.Open();
                exists = (int)cmd2.ExecuteScalar() > 0;
                sqlcon.Close();
            }            
            if (exists)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert('This Username already exists');", true);
            }
            else
            {
                SqlCommand cmd = new SqlCommand(Conn);
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "CreateUser";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = txtName.Text;
                cmd.Parameters.Add("@persal", SqlDbType.VarChar).Value = txtPersal.Text;
                cmd.Parameters.Add("@surname", SqlDbType.VarChar).Value = txtSurname.Text;
                cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = txtUsername.Text;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtPassword.Text;
                cmd.Parameters.Add("@role", SqlDbType.VarChar).Value = ddlRole.SelectedItem.Text;
                cmd.Parameters.Add("@email", SqlDbType.VarChar).Value = txtEmail.Text;

                sqlcon.Open();
                cmd.ExecuteNonQuery();
                sqlcon.Close();

                txtUsername.Text = "";
                txtName.Text = "";
                txtPersal.Text = "";
                txtSurname.Text = "";
                txtPassword.Text = "";
                txtEmail.Text = "";
                ddlRole.SelectedIndex = 0;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert('User details successfully saved');", true);
            }

        }
        catch
        {

        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void txtPersal_TextChanged(object sender, EventArgs e)
    {
        string Username;
        Username= txtPersal.Text;
        txtUsername.Text = Username;

    }
}