﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Configuration;

public partial class Administrator_Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bindGriview();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtAgencyName.Text != string.Empty)
            {

                SqlCommand cmd = new SqlCommand();
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "InsertAdvertisingAgency";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@advertising_agency_name", SqlDbType.NVarChar).Value = txtAgencyName.Text;

                sqlcon.Open();

                cmd.ExecuteNonQuery();

                sqlcon.Close();

                txtAgencyName.Text = "";
                showMessage("Advertising Agency saved successfully.");
                bindGriview();
            }
            else
            {
                showMessage("Enter Agency Name");
            }
        }
        catch
        {

        }
    }
    protected void btnCancel0_Click(object sender, EventArgs e)
    {
        Response.Redirect("home.aspx");
    }
    public void showMessage(string message)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + message + "');", true);
    }
    private void bindGriview()
    {
        SqlCommand cmd2 = new SqlCommand("select * from advertising_agency ");

        this.sqlcon.ConnectionString = this.Conn;
        cmd2.Connection = this.sqlcon;

        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);
        GridView1.DataSource = dt2;
        GridView1.DataBind();


    }
    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(Conn);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        return dt;
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bindGriview();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }  

   
    protected void EditRow(object sender, GridViewEditEventArgs e)
    {

        GridView1.EditIndex = e.NewEditIndex;
        bindGriview();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bindGriview();
    }
    protected void UpdateRow(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            int id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text);

            string AgencyName = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtAgencyName")).Text;
           
            SqlConnection con = new SqlConnection(Conn);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update advertising_agency set advertising_agency_name=@advertising_agency_name " + "where advertising_agency_id=@advertising_agency_id";
            cmd.Parameters.Add("@advertising_agency_id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@advertising_agency_name", SqlDbType.VarChar).Value = AgencyName;
         
            GridView1.EditIndex = -1;
            GridView1.DataSource = GetData(cmd);
            GridView1.DataBind();

            bindGriview();
        }
        catch
        {


        }
    }
}
