﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            //SetPreviousData();
            sqlcon = new SqlConnection(Conn);
            String sql = "Select * from interview_details where post_reference = '" + Request["Ref"].ToString() + "' and (idno ='" + Request["id"].ToString() + "'or Passport ='" + Request["id"].ToString() + "')";
            sqlcon.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
            SqlDataReader dr = sqlcmd.ExecuteReader();

            while (dr.Read())
            {
                string interviewID = dr["interview_id"].ToString();

                Session["interview_id"] = interviewID;

                dpInterviewDate.Text = Convert.ToDateTime(dr["interview_date"]).ToString("yyyy-MM-dd", null);
                txtInterviewVenue.Text = dr["interview_venue"].ToString();
                txtInternalOrExternalCandidate.Text = dr["internal_external_candidate"].ToString();
                txtPostApplied.Text = dr["post_applied"].ToString();
                txtResponsibleManager.Text = dr["responsible_line_manager"].ToString();

                dpDateVettingSent.Text = Convert.ToDateTime(dr["date_vetting_sent"]).ToString("yyyy-MM-dd", null);
                //ddlVettingReceived.SelectedItem.Text = dr["security_vetting_received"].ToString();
                //ddlQualification_Vetting.SelectedItem.Text = dr["qualification_vetting_received"].ToString();
                if (dr["qualification_vetting_received"].ToString() == "Yes")
                {
                    ddlQualification_Vetting.SelectedIndex = 1;
                }
                else if (dr["qualification_vetting_received"].ToString() == "No")
                {
                    ddlQualification_Vetting.SelectedIndex = 2;
                }
                else
                {
                    ddlQualification_Vetting.SelectedIndex = 0;
                }
                if (dr["security_vetting_received"].ToString() == "Yes")
                {
                    ddlVettingReceived.SelectedIndex = 1;
                }
                else if (dr["security_vetting_received"].ToString() == "No")
                {
                    ddlVettingReceived.SelectedIndex = 2;
                }
                else
                {
                    ddlVettingReceived.SelectedIndex = 0;
                }
                dpDateOfSubmission.Text = Convert.ToDateTime(dr["date_of_submitted"]).ToString("yyyy-MM-dd", null);
                dpDateOfApproval.Text = Convert.ToDateTime(dr["date_of_approval"]).ToString("yyyy-MM-dd", null);

                string ID = dr["idNo"].ToString();
                string passport = dr["passport"].ToString();

                if (ID != "")
                {
                    txtCandidate.Text = dr["idNo"].ToString();
                    txtCandidate.Enabled = false;
                }
                else
                {
                    txtCandidate.Text = dr["passport"].ToString();
                    txtCandidate.Enabled = false;
                }

                txtInterviewPoints.Text = dr["interview_points"].ToString();
                ddlDecisionMade.Text = dr["decision_made"].ToString();
                //if (myReader["Additional"] != DBNull.Value)
                if (dr["appointed_date"] !=DBNull.Value)
                {
                    dpAppointmentDate.Text = Convert.ToDateTime(dr["appointed_date"]).ToString("yyyy-MM-dd", null);                    
                }
                else 
                {
                    dpAppointmentDate.Text = string.Empty;//Convert.ToDateTime(dr["appointed_date"]).ToString("yyyy-MM-dd", null); 
                }
                //dpAppointmentDate.Text = Convert.ToDateTime(dr["appointed_date"]).ToString("yyyy-MM-dd", null);
                if (dr["comments"] != DBNull.Value)
                {
                    txtComments.Text = dr["comments"].ToString();                    
                }
                else 
                {
                    txtComments.Text = string.Empty;//dr["comments"].ToString();  
                }
                


            }
            dr.Close();
            sqlcon.Close();

            bindGriview();


        }

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Validate_Fields();

        SqlCommand cmd = new SqlCommand();
        sqlcon.ConnectionString = Conn;
        cmd.Connection = sqlcon;

        cmd.CommandText = "UpdateInterviewDetails";
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@post_reference", Request["Ref"].ToString());
        cmd.Parameters.AddWithValue("@idNo", Request["id"].ToString());
        cmd.Parameters.AddWithValue("@passport", Request["id"].ToString());

        cmd.Parameters.Add("@interview_date", SqlDbType.DateTime).Value = dpInterviewDate.Text;
        cmd.Parameters.Add("@interview_venue", SqlDbType.VarChar).Value = txtInterviewVenue.Text;
        cmd.Parameters.Add("@internal_external_candidate", SqlDbType.VarChar).Value = txtInternalOrExternalCandidate.Text;
        cmd.Parameters.Add("@post_applied", SqlDbType.VarChar).Value = txtPostApplied.Text;
        //cmd.Parameters.Add("@names_of_interviewer", SqlDbType.VarChar).Value = txtNamesOfInterviewers.Text;
        cmd.Parameters.Add("@responsible_line_manager", SqlDbType.VarChar).Value = txtResponsibleManager.Text;

        cmd.Parameters.Add("@date_vetting_sent", SqlDbType.DateTime).Value = dpDateVettingSent.Text;
        cmd.Parameters.Add("@security_vetting_received", SqlDbType.VarChar).Value = ddlVettingReceived.SelectedItem.Text;
        cmd.Parameters.Add("@qualification_vetting_received", SqlDbType.VarChar).Value = ddlQualification_Vetting.SelectedItem.Text;

        cmd.Parameters.Add("@date_of_submitted", SqlDbType.DateTime).Value = dpDateOfSubmission.Text;
        cmd.Parameters.Add("@date_of_approval", SqlDbType.DateTime).Value = dpDateOfApproval.Text;

        //cmd.Parameters.Add("@criteria_points", SqlDbType.VarChar).Value = txtCriteriaPoints.Text;
        cmd.Parameters.Add("@interview_points", SqlDbType.VarChar).Value = txtInterviewPoints.Text;
        //cmd.Parameters.Add("@total_points", SqlDbType.VarChar).Value = txtTotalPoints.Text;
        cmd.Parameters.Add("@decision_made", SqlDbType.VarChar).Value = ddlDecisionMade.SelectedValue;
        if (dpAppointmentDate.Text == string.Empty)
        {
            cmd.Parameters.Add("@appointed_date", SqlDbType.DateTime).Value = DBNull.Value;
        }
        else
        {
            cmd.Parameters.Add("@appointed_date", SqlDbType.DateTime).Value = dpAppointmentDate.Text;
        }
        cmd.Parameters.Add("@comments ", SqlDbType.VarChar).Value = txtComments.Text;

        if (FileUpload1.HasFile)
        {
            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);

            FileUpload1.SaveAs(Server.MapPath("HOD Approval Docs/" + filename));

            cmd.Parameters.AddWithValue("@hod_submission_approval", filename);

            cmd.Parameters.AddWithValue("@hod_approval_file_path", "HOD Approval Docs/" + filename);

        }
        else
        {            
            cmd.Parameters.Add("@hod_submission_approval", SqlDbType.VarChar).Value = DBNull.Value;
            cmd.Parameters.Add("@hod_approval_file_path ", SqlDbType.VarChar).Value = DBNull.Value;
        }

        if (FileUpload2.HasFile)
        {
            string filename2 = Path.GetFileName(FileUpload2.PostedFile.FileName);

            FileUpload2.SaveAs(Server.MapPath("Candidate Docs/" + filename2));

            cmd.Parameters.AddWithValue("@candidate_submission_approval", filename2);

            cmd.Parameters.AddWithValue("@candidate_approval_file_path", "Candidate Docs/" + filename2);
        }
        else
        {
            cmd.Parameters.Add("@candidate_submission_approval", SqlDbType.VarChar).Value = DBNull.Value;
            cmd.Parameters.Add("@candidate_approval_file_path ", SqlDbType.VarChar).Value = DBNull.Value;
        }

        sqlcon.Open();
        cmd.ExecuteNonQuery();

        sqlcon.Close();

        ShowMessage("Interview details successfully updated.");
    }
    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Interview details successfully updated.');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    private void bindGriview()
    {
        SqlCommand cmd2 = new SqlCommand("select * from interview_panel where post_reference = '" + Request["Ref"].ToString() + "' and interview_id = ' " + Session["interview_id"] + " '");

        this.sqlcon.ConnectionString = this.Conn;
        cmd2.Connection = this.sqlcon;

        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);
        GridView1.DataSource = dt2;
        GridView1.DataBind();
    }



    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(Conn);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        return dt;
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bindGriview();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void AddNewRow(object sender, EventArgs e)
    {
        int interviewID = Convert.ToInt32(Session["interview_id"]);
        string postRef = Request["Ref"].ToString();

        string names = ((TextBox)GridView1.FooterRow.FindControl("txtName_Surname")).Text;
        string rank = ((TextBox)GridView1.FooterRow.FindControl("txtRank")).Text;
        string designation = ((TextBox)GridView1.FooterRow.FindControl("txtDesignation")).Text;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into interview_panel(post_reference,interview_id,names, rank, designation) " + "values(@post_reference,@interview_id,@names, @rank, @designation)";

        cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = postRef;
        cmd.Parameters.Add("@interview_id", SqlDbType.Int).Value = interviewID;
        cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
        cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
        cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();


        bindGriview();
    }

    protected void DeleteRow(object sender, EventArgs e)
    {

        LinkButton lnkRemove = (LinkButton)sender;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from  interview_panel where " + "id=@id";
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = lnkRemove.CommandArgument;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
    protected void EditRow(object sender, GridViewEditEventArgs e)
    {


        GridView1.EditIndex = e.NewEditIndex;
        bindGriview();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bindGriview();
    }
    protected void UpdateRow(object sender, GridViewUpdateEventArgs e)
    {

        int id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text);


        string names = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtName_Surname")).Text;
        string rank = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtRank")).Text;
        string designation = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDesignation")).Text;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "update interview_panel set names=@names,rank=@rank,designation=@designation " + "where id=@id";
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
        cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
        cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
        cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
        GridView1.EditIndex = -1;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();

    }
    public void Validate_Fields()
    {
        if (dpInterviewDate.Text == string.Empty)
        {
            Message("Please enter interview date.");
            dpInterviewDate.Focus();
            return;
        }
        else if (txtInterviewVenue.Text == string.Empty)
        {
            Message("Please enter interview venue.");
            txtInterviewVenue.Focus();
            return;
        }
        else if (txtInternalOrExternalCandidate.SelectedIndex == 0)
        {
            Message("Please select whether is Internal/External candidate.");
            txtInternalOrExternalCandidate.Focus();
            return;
        }

        else if (txtResponsibleManager.Text == string.Empty)
        {
            Message("Please enter the responsible line manager.");
            txtResponsibleManager.Focus();
            return;
        }
        else if (dpDateVettingSent.Text == string.Empty)
        {
            Message("Please enter the date vetting sent.");
            dpDateVettingSent.Focus();
            return;
        }
        else if (ddlVettingReceived.SelectedIndex == 0)
        {
            Message("Please select if security vetting received.");
            ddlVettingReceived.Focus();
            return;
        }
        //else if (FileUpload2.HasFile == false) 
        //{
        //    Message("Please upload candidate documents.");
        //    FileUpload2.Focus();
        //    return;        
        //}
        else if (ddlQualification_Vetting.SelectedIndex == 0)
        {
            Message("Please select if qualification vetting received.");
            ddlQualification_Vetting.Focus();
            return;
        }
        //else if (FileUpload1.HasFile == false)
        //{
        //    Message("Please upload HOD documents.");
        //    FileUpload1.Focus();
        //    return;
        //}
        else if (dpDateOfSubmission.Text == string.Empty)
        {
            Message("Please enter date of submission.");
            dpDateOfSubmission.Focus();
            return;
        }
        //else if (ddlCandidateDetails.SelectedIndex == 0)
        //{
        //    Message("Please select candidate details.");
        //    ddlCandidateDetails.Focus();
        //    return;
        //}
        else if (dpDateOfApproval.Text == string.Empty)
        {
            Message("Please enter date of approval.");
            dpDateOfApproval.Focus();
            return;
        }
        else if (txtInterviewPoints.Text == string.Empty)
        {
            Message("Please enter interview points.");
            txtInterviewPoints.Focus();
            return;
        }
        //else if (ddlDecisionMade.SelectedIndex == 0)
        //{
        //    Message("Please select decision made.");
        //    ddlDecisionMade.Focus();
        //    return;
        //}
        //else if (dpAppointmentDate.Text == string.Empty)
        //{
        //    Message("Please enter appointment date.");
        //    dpAppointmentDate.Focus();
        //    return;
        //}
    }

    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + msg + "');", true);
    }
    protected void RangeValidator_Init(object sender, EventArgs e)
    {
        ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();


    }


}




