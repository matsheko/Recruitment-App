﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Administrator_Default2 : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGridview();
        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    public void Message(string msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
        "alert('" + msg + "');", true);
    }
    public void BindGridview()
    {
        try
        {
            SqlCommand cmd = new SqlCommand(Conn);
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "ReportAppointmentDetail";
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            //GridView1.FooterRow.Cells[0].Text = "Total Number of positions advertised";
            //GridView1.FooterRow.Cells[3].Text = dt.Compute("Sum(no_of_posts)", "").ToString();

            sqlcon.Close();
        }
        catch
        {
            Message("Error!!! Please contact system administrator");
        }
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ClearContent();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.Charset = "";
            string FileName = "RSS_Report_Appointments_" + DateTime.Now.ToShortDateString() + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            GridView1.GridLines = GridLines.Both;
            GridView1.HeaderStyle.Font.Bold = true;
            GridView1.RenderControl(htmltextwrtter);
            HttpContext.Current.Response.Write(strwritter.ToString());
            HttpContext.Current.Response.End();
            System.Web.HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
        catch
        {
            Message("Error!!! Please contact system administrator");
        }
    }
    protected void OnDataBound(object sender, EventArgs e)
    {
        for (int i = GridView1.Rows.Count - 1; i > 0; i--)
        {

        }
    }
}