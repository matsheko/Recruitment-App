﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections.Specialized;
using System.Text;
using System.Collections;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Page.MaintainScrollPositionOnPostBack = true;
            if (!IsPostBack)
            {
                SetInitialRow();
                string shortlisted = "";
                string idPassport = "";

                sqlcon = new SqlConnection(Conn);
                String sql = "Select * from shortlisting_commitee where post_reference = '" + Request["id"].ToString() + "'";
                sqlcon.Open();

                SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
                SqlDataReader dr = sqlcmd.ExecuteReader();

                while (dr.Read())
                {
                    shortlisted = dr["shortlistedCandidates"].ToString();
                    idPassport = dr["idPassport"].ToString();
                    //idPassport = Session["idpassport"].ToString();
                }
                string[] names = shortlisted.Split(',');
                string[] id = idPassport.Split(',');

                for (int i = 0; i < names.Length; i++)
                {
                    ListItem li = new ListItem();
                    li.Value = id[i].ToString();
                    li.Text = names[i].ToString();
                    ddlCandidateDetails.Items.Add(li);
                }
                bindPostApplied();
            }
        }
        catch
        {

        }
    }
    public void MessageValidate(string message)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("<script type = 'text/javascript'>");
        sb.Append("window.onload=function(){");
        sb.Append("alert('");
        sb.Append(message);
        sb.Append("')};");
        sb.Append("</script>");
        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
    }
    public void Check_If_Exists() 
    {
        
            this.sqlcon.ConnectionString = this.Conn;
            this.sqlcon.Open();
            string strQuery1 = "Select COUNT(passport) from interview_details Where post_reference=@Post_ref and passport=@passport";
            SqlCommand cmd1 = new SqlCommand(strQuery1);
            cmd1.Parameters.AddWithValue("@Post_ref", Request["id"].ToString());
            cmd1.Parameters.AddWithValue("@passport", ddlCandidateDetails.SelectedValue);
            cmd1.Connection = this.sqlcon;
            int Count = (int)cmd1.ExecuteScalar();
            if (Count > 0)
            {
                this.MessageValidate("Interview details for this candidate has already been captured");
                //txtPersal.Focus();
                this.sqlcon.Close();
                return;
            }
            else 
            {
               // Continue
            }
    }
    private ArrayList GetDummyData()
    {
        ArrayList arr = new ArrayList();
        arr.Add(new ListItem("Chairperson", "1"));
        arr.Add(new ListItem("Panel Member", "2"));
        arr.Add(new ListItem("Union Representative", "3"));
        arr.Add(new ListItem("HR Representative", "4"));
        return arr;
    }
    private void FillDropDownList(DropDownList ddl)
    {
        ArrayList arr = GetDummyData();
        foreach (ListItem item in arr)
        {
            ddl.Items.Add(item);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {        
    }
    private void InsertRecords(StringCollection sc)
    {
        SqlConnection Sqlconn = new SqlConnection();
        Sqlconn.ConnectionString = Conn;
        StringBuilder sb = new StringBuilder(string.Empty);
        string[] splitItems = null;
        foreach (string item in sc)
        {

            const string sqlStatement = "INSERT INTO interview_panel (names,rank,designation,interview_id,post_reference) VALUES";
            if (item.Contains(","))
            {
                splitItems = item.Split(",".ToCharArray());
                sb.AppendFormat("{0}('{1}','{2}','{3}','{4}','{5}'); ", sqlStatement, splitItems[0], splitItems[1], splitItems[2], splitItems[3], splitItems[4]);
            }
        }
        try
        {
            Sqlconn.Open();
            SqlCommand cmd = new SqlCommand(sb.ToString(), Sqlconn);

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            //Display a popup which indicates that the record was successfully inserted
            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Script", "alert('Records Successfuly Saved!');", true);

        }
        catch (System.Data.SqlClient.SqlException ex)
        {
            string msg = "Insert Error:";
            msg += ex.Message;
            throw new Exception(msg);
        }
        finally
        {
            Sqlconn.Close();
        }
    }
    public void bindPostApplied()
    {
        sqlcon = new SqlConnection(Conn);
        String sql = "Select post_applied from PostDetails where Post_ref_no = '" + Request["id"].ToString() + "'";
        sqlcon.Open();

        SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
        SqlDataReader dr = sqlcmd.ExecuteReader();

        while (dr.Read())
        {
            txtPostApplied.Text = dr["post_applied"].ToString();
            txtPostApplied.Enabled = false;
        }

    }
    public void Validate_Fields()
    {
        if (dpInterviewDate.Text == string.Empty)
        {
            Message("Please enter interview date.");
            dpInterviewDate.Focus();
            return;
        }
        else if (Convert.ToDateTime(dpInterviewDate.Text) > DateTime.Today)
        {
            Message("Interview date cannot be a furure date.");
            dpInterviewDate.Focus();
            return;
        }
        else if (txtInterviewVenue.Text == string.Empty)
        {
            Message("Please enter interview venue.");
            txtInterviewVenue.Focus();
            return;
        }
        else if (txtInternalOrExternalCandidate.SelectedIndex == 0)
        {
            Message("Please select whether is Internal/External candidate.");
            txtInternalOrExternalCandidate.Focus();
            return;
        }

        else if (txtResponsibleManager.Text == string.Empty)
        {
            Message("Please enter the responsible line manager.");
            txtResponsibleManager.Focus();
            return;
        }
        else if (dpDateVettingSent.Text == string.Empty)
        {
            Message("Please enter the date vetting sent.");
            dpDateVettingSent.Focus();
            return;
        }
        else if (Convert.ToDateTime(dpDateVettingSent.Text) > DateTime.Today)
        {
            Message("Date vetting sent cannot be a future date.");
            dpDateVettingSent.Focus();
            return;
        }
        else if (ddlVettingReceived.SelectedIndex == 0 || ddlVettingReceived.SelectedItem.Text == "Select One....")
        {
            Message("Please select if security vetting received.");
            ddlVettingReceived.Focus();
            return;
        }

        else if (ddlQualification_Vetting.SelectedIndex == 0 || ddlQualification_Vetting.SelectedItem.Text == "Select One....")
        {
            Message("Please select if qualification vetting received.");
            ddlQualification_Vetting.Focus();
            return;
        }
        else if (FileUpload1.HasFile == false)
        {
            Message("Please upload HOD documents.");
            FileUpload1.Focus();
            return;
        }
        else if (dpDateOfSubmission.Text == string.Empty)
        {
            Message("Please enter date of submission.");
            dpDateOfSubmission.Focus();
            return;
        }
       
        else if (ddlCandidateDetails.SelectedItem.Text == "Select One...")
        {
            Message("Please select candidate details.");
            ddlCandidateDetails.Focus();
            return;
        }
        else if (dpDateOfApproval.Text == string.Empty)
        {
            Message("Please enter date of approval.");
            dpDateOfApproval.Focus();
            return;
        }
        else if (txtInterviewPoints.Text == string.Empty)
        {
            Message("Please enter interview points.");
            txtInterviewPoints.Focus();
            return;
        }
        //else if (ddlDecisionMade.SelectedItem.Text == "Select One....")
        //{
        //    Message("Please select decision made.");
        //    ddlDecisionMade.Focus();
        //    return;
        //}
        //else if (dpAppointmentDate.Text == string.Empty)
        //{
        //    Message("Please enter appointment date.");
        //    dpAppointmentDate.Focus();
        //    return;
        //}

        if (Convert.ToDateTime(dpDateOfSubmission.Text) > DateTime.Today)
        {
            Message("Date of submission cannot be a future date.");
            dpDateOfSubmission.Focus();
            return;
        }
    }
    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + msg + "');", true);
    }
    public void Message1(string message)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        sb.Append("<script type = 'text/javascript'>");
        sb.Append("window.onload=function(){");
        sb.Append("alert('");
        sb.Append(message);
        sb.Append("')};");
        sb.Append("</script>");
        ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //Check_If_Interview_Deatils_Already_Exists;
        this.sqlcon.ConnectionString = this.Conn;
        this.sqlcon.Open();
        string strQuery1 = "Select COUNT(passport) from interview_details Where post_reference=@Post_ref and passport=@passport";
        SqlCommand cmd1 = new SqlCommand(strQuery1);
        cmd1.Parameters.AddWithValue("@Post_ref", Request["id"].ToString());
        cmd1.Parameters.AddWithValue("@passport", ddlCandidateDetails.SelectedValue);
        cmd1.Connection = this.sqlcon;
        int Count = (int)cmd1.ExecuteScalar();
        if (Count > 0)
        {
            Message("Interview details for this candidate has already been captured for this position.");
            this.sqlcon.Close();
            return;
        }
        else
        {
            this.sqlcon.Close();
        }
        //Check_If_Interview_Deatils_Already_Exists;
        this.sqlcon.ConnectionString = this.Conn;
        this.sqlcon.Open();
        string strQuery2 = "Select COUNT(idNo) from interview_details Where post_reference=@Post_ref1 and idNo=@idNo";
        SqlCommand cmd2 = new SqlCommand(strQuery2);
        cmd2.Parameters.AddWithValue("@Post_ref1", Request["id"].ToString());
        cmd2.Parameters.AddWithValue("@idNo", ddlCandidateDetails.SelectedValue);
        cmd2.Connection = this.sqlcon;
        int Count2 = (int)cmd2.ExecuteScalar();
        if (Count2 > 0)
        {
            Message("Interview details for this candidate has already been captured for this position.");
            this.sqlcon.Close();
            return;
        }
        else
        {
            this.sqlcon.Close();
        }

        Validate_Fields();
        try
        {

            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "insertInterviewDetails";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@interview_date", SqlDbType.DateTime).Value = dpInterviewDate.Text;
            cmd.Parameters.Add("@interview_venue", SqlDbType.VarChar).Value = txtInterviewVenue.Text;
            cmd.Parameters.Add("@internal_external_candidate", SqlDbType.VarChar).Value = txtInternalOrExternalCandidate.Text;
            cmd.Parameters.Add("@post_applied", SqlDbType.VarChar).Value = txtPostApplied.Text;
            //cmd.Parameters.Add("@names_of_interviewer", SqlDbType.VarChar).Value = txtNamesOfInterviewers.Text;
            cmd.Parameters.Add("@responsible_line_manager", SqlDbType.VarChar).Value = txtResponsibleManager.Text;

            cmd.Parameters.Add("@date_vetting_sent", SqlDbType.DateTime).Value = dpDateVettingSent.Text;
            cmd.Parameters.Add("@security_vetting_received", SqlDbType.VarChar).Value = ddlVettingReceived.SelectedItem.Text;
            cmd.Parameters.Add("@qualification_vetting_received", SqlDbType.VarChar).Value = ddlQualification_Vetting.SelectedItem.Text;
            cmd.Parameters.Add("@date_of_submitted", SqlDbType.DateTime).Value = dpDateOfSubmission.Text;
            cmd.Parameters.Add("@date_of_approval", SqlDbType.DateTime).Value = dpDateOfApproval.Text;

            if (ddlCandidateDetails.SelectedItem.Value.Length == 13)
            {
                cmd.Parameters.Add("@idNo", SqlDbType.VarChar).Value = ddlCandidateDetails.SelectedItem.Value;
                cmd.Parameters.Add("@passport", SqlDbType.VarChar).Value = "";
            }
            else
            {
                cmd.Parameters.Add("@passport", SqlDbType.VarChar).Value = ddlCandidateDetails.SelectedItem.Value;
                cmd.Parameters.Add("@idNo", SqlDbType.VarChar).Value = "";
            }

            //cmd.Parameters.Add("@criteria_points", SqlDbType.VarChar).Value = txtCriteriaPoints.Text;
            cmd.Parameters.Add("@interview_points", SqlDbType.VarChar).Value = txtInterviewPoints.Text;
            //cmd.Parameters.Add("@total_points", SqlDbType.VarChar).Value = txtTotalPoints.Text;
            cmd.Parameters.Add("@decision_made", SqlDbType.VarChar).Value = ddlDecisionMade.SelectedItem.Text;
            if (dpAppointmentDate.Text == string.Empty)
            {
                cmd.Parameters.Add("@appointed_date", SqlDbType.DateTime).Value = DBNull.Value;
            }
            else 
            {
                cmd.Parameters.Add("@appointed_date", SqlDbType.DateTime).Value = dpAppointmentDate.Text;
            }           
            cmd.Parameters.Add("@comments ", SqlDbType.VarChar).Value = txtComments.Text;
            cmd.Parameters.Add("@post_reference ", SqlDbType.VarChar).Value = Request.QueryString["ID"].ToString();

            if (FileUpload1.HasFile)
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);

                FileUpload1.SaveAs(Server.MapPath("HOD Approval Docs/" + filename));

                cmd.Parameters.AddWithValue("@hod_submission_approval", filename);

                cmd.Parameters.AddWithValue("@hod_approval_file_path", "HOD Approval Docs/" + filename);

            }
            if (FileUpload2.HasFile)
            {
                string filename2 = Path.GetFileName(FileUpload2.PostedFile.FileName);

                FileUpload2.SaveAs(Server.MapPath("Candidate Docs/" + filename2));

                cmd.Parameters.AddWithValue("@candidate_submission_approval", filename2);

                cmd.Parameters.AddWithValue("@candidate_approval_file_path", "Candidate Docs/" + filename2);
            }
            else
            {
                cmd.Parameters.Add("@candidate_submission_approval", SqlDbType.VarChar).Value = string.Empty;
                cmd.Parameters.Add("@candidate_approval_file_path ", SqlDbType.VarChar).Value = string.Empty;
            }
            cmd.Parameters.Add("@NewId", SqlDbType.Int).Direction = ParameterDirection.Output;
            sqlcon.Open();
            cmd.ExecuteNonQuery();

            int num = Convert.ToInt32(cmd.Parameters["@NewId"].Value);
            this.Session["interview_id"] = num;
            sqlcon.Close();

            //Save to the interview panel table
            int rowIndex = 0;
            StringCollection sc = new StringCollection();
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        //extract the TextBox values
                        TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                        TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");
                        DropDownList box3 = (DropDownList)GridView1.Rows[rowIndex].Cells[2].FindControl("ddlDesignation");

                        //get the values from the TextBoxes
                        //then add it to the collections with a comma "," as the delimited values
                        sc.Add(box1.Text + "," + box2.Text + "," + box3.SelectedItem.Text + "," + this.Session["interview_id"].ToString() + "," + Request.QueryString["ID"].ToString());
                        rowIndex++;
                    }
                    //Call the method for executing inserts
                    InsertRecords(sc);
                }
            }
            ShowMessage("Interview details successfully saved.");
        }
        catch
        {

        }
    }
    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Interview details successfully saved.');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    protected void ddlCandidateDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    private void AddNewRowToGrid()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");                    
                    DropDownList box3 = (DropDownList)GridView1.Rows[rowIndex].Cells[2].FindControl("ddlDesignation");
                    drCurrentRow = dtCurrentTable.NewRow();
                    dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;
                    dtCurrentTable.Rows[i - 1]["Column3"] = box3.SelectedItem.Text;                    

                    rowIndex++;
                }

                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                GridView1.DataSource = dtCurrentTable;
                GridView1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");                    
                    DropDownList box3 = (DropDownList)GridView1.Rows[rowIndex].Cells[2].FindControl("ddlDesignation");

                    //Fill the DropDownList with Data
                    FillDropDownList(box3);
                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();
                    //box3.SelectedItem.Text = dt.Rows[i]["Column3"].ToString();
                    if (i < dt.Rows.Count - 1)
                    {
                        box3.ClearSelection();
                        box3.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;
                    }
                    rowIndex++;
                }
            }
        }
    }
   
    private void SetInitialRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        //dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dr["Column3"] = string.Empty;
        dt.Rows.Add(dr);
        //dr = dt.NewRow();

        //Store the DataTable in ViewState
        ViewState["CurrentTable"] = dt;

        GridView1.DataSource = dt;
        GridView1.DataBind();
        DropDownList ddl3 = (DropDownList)GridView1.Rows[0].Cells[3].FindControl("ddlDesignation");
        FillDropDownList(ddl3);
    }

    protected void txtInternalOrExternalCandidate_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");

    }

    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
       
    }
    public void MesageBox(string mgs, string url)
    {
        string script = "window.onload = function(){ alert('";
        script += mgs;
        script += "');";
        script += "window.location = '";
        script += url;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
    }
    protected void ddlVettingReceived_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void RangeValidator_Init(object sender, EventArgs e)
    {
        ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex + 1;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data
                    dt.Rows.Remove(dt.Rows[rowID]);
                }
            }
            //Store the current data in ViewState for future reference
            ViewState["CurrentTable"] = dt;
            //Re bind the GridView for the updated data
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }
}