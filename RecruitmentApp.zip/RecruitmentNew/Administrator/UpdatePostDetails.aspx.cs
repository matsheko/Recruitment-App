﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    SqlConnection sqlcon3 = new SqlConnection();
    SqlConnection sqlcon4 = new SqlConnection();
    int count;
    string BU;

    protected void Page_Load(object sender, EventArgs e)
    {
        countRows();
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            this.LoadBranch_advertised_post();

            LoadAgencies();
            LoadOSDcategory();

            txtPostRefNo.Enabled = false;
            txtBranch.Enabled = false;
            txtChiefDirectorate.Enabled = false;
            txtDirectorate.Enabled = false;
            txtComponent.Enabled = false;

            sqlcon = new SqlConnection(Conn);
            String sql = "Select * from PostDetails where post_ref_no = '" + Request.QueryString["id"].ToString() + "' ";
            sqlcon.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
            SqlDataReader dr = sqlcmd.ExecuteReader();

            while (dr.Read())
            {
                HiddenField_postID.Value = dr["post_id"].ToString();
                HiddenField2.Value = dr["Branch_advertised_post"].ToString();
                txtChiefDirectorate.Text = dr["Chief_Directorate_advertised_post"].ToString();
                txtDirectorate.Text = dr["Directorate_advertised_post"].ToString();
                txtComponent.Text = dr["Sub_Directorate"].ToString();
                txtPostApplied.Text = dr["post_applied"].ToString();
                txtPostRefNo.Text = dr["Post_ref_no"].ToString();
                ddlPostLevel.Text = dr["Post_Level"].ToString();
                ddlVacantorFilled.SelectedItem.Text = dr["vacant_filled"].ToString();
                txtPostSalaryNotch.Text = dr["Post_Salary_Notch"].ToString();
                dpPostDateAdvertised.Text = Convert.ToDateTime(dr["post_date_advertised"]).ToString("yyyy/MM/dd", null);
                dpPostClosingDate.Text = Convert.ToDateTime(dr["post_closing_date"]).ToString("yyyy/MM/dd", null);
                dpMediaPublicDate.Text = Convert.ToDateTime(dr["media_public_date"]).ToString("yyyy/MM/dd", null);
                ListBox1.Text = dr["advertising_agency"].ToString();
                txtCostOfAdvert.Text = dr["cost_of_advert"].ToString();
                ddlResponse.Text = dr["response_handling"].ToString();
                txtComments.Text = dr["comments"].ToString();
                dpPostDateCreated.Text = Convert.ToDateTime(dr["date_post_created"]).ToString("yyyy/MM/dd", null);
                ddlExtOrInt.SelectedValue = dr["internalOrExternal"].ToString();
                ddlOSD.SelectedValue = dr["OSD_or_non_OSD"].ToString();
                txtNoOfPosts.Text = dr["no_of_posts"].ToString();
                txtComponent.Text = dr["Component"].ToString();
                if (txtComments.Text == "")
                {
                    txtComments.Visible = false;
                    lblComments.Visible = false;
                }
                else if (txtComments.Text != "")
                {
                    txtComments.Visible = true;
                    lblComments.Visible = true;
                }

                if (ddlOSD.SelectedItem.Text == "OSD")
                {
                    ddlPostLevel.Enabled = false;
                }

                if (ddlOSD.SelectedItem.Text == "OSD")
                {
                    ddlOSDCategory.Enabled = true;
                    Label1.Text = dr["OSD_category"].ToString();
                }
                if (ddlOSD.SelectedItem.Text == "OSD")
                {
                    ddlOSDPost_grade.Enabled = true;
                    txtOSD_post_grade.Visible = true;
                    ddlOSDPost_grade.Visible = false;
                    txtOSD_post_grade.Text = dr["Post_Level"].ToString();
                }
            }

            ddlBranch_advertised_post.SelectedItem.Text = HiddenField2.Value;
            if (ddlOSD.SelectedValue == "OSD")
            {
                ddlOSDCategory.SelectedItem.Text = Label1.Text;

            }
            else
            {
                ddlOSDCategory.Enabled = false;
            }
        }
    }
    protected void LoadBranch_advertised_post()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT branch_id, branch_name from branch");
        this.sqlcon3.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon3;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlBranch_advertised_post.DataSource = dataTable;
            this.ddlBranch_advertised_post.DataTextField = "branch_name";
            this.ddlBranch_advertised_post.DataValueField = "branch_id";
            this.ddlBranch_advertised_post.DataBind();
            this.ddlBranch_advertised_post.Items.Insert(0, "Select One...");


        }
        sqlcon3.Close();
    }
    protected void LoadChief_Directorate(int branch_id)
    {
        SqlCommand cmd = new SqlCommand("SELECT Chief_Dire_id,Chief_Dire_Name from Chief_Directorate where Branch_ID = @Brach_id ORDER BY Chief_Dire_Name ASC ");
        cmd.Parameters.AddWithValue("@Brach_id", branch_id);
        this.sqlcon3.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon3;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlChief_Directorate_advertised_post.DataSource = dataTable;
            this.ddlChief_Directorate_advertised_post.DataTextField = "Chief_Dire_Name";
            this.ddlChief_Directorate_advertised_post.DataValueField = "Chief_Dire_id";
            this.ddlChief_Directorate_advertised_post.DataBind();
            this.ddlChief_Directorate_advertised_post.Items.Insert(0, "Select One...");
        }
        sqlcon3.Close();
    }
    protected void LoadDirectorate(int Chief_Dire_id)
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Directorate_id,Directorate_Name from Directorates where  Chief_Dire_ID = @Chief_Dire_id ORDER BY Directorate_Name ASC");
        selectCommand.Parameters.AddWithValue("@Chief_Dire_id", Chief_Dire_id);
        this.sqlcon3.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon3;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDirectorate_advertised_post.DataSource = dataTable;
            this.ddlDirectorate_advertised_post.DataTextField = "Directorate_Name";
            this.ddlDirectorate_advertised_post.DataValueField = "Directorate_id";
            this.ddlDirectorate_advertised_post.DataBind();
            this.ddlDirectorate_advertised_post.Items.Insert(0, "Select One...");
        }
        sqlcon3.Close();
    }
    protected void LoadSub_Directorate(int Directorate_id)
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Sub_Directorate_id ,Sub_Directorate_Name from Sub_Directorates where Directorate_ID= @Directorate_ID  ORDER BY Sub_Directorate_Name ASC");
        selectCommand.Parameters.AddWithValue("@Directorate_id", Directorate_id);
        this.sqlcon3.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon3;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            ddlComponet_advertised_post.Items.Clear();

            this.ddlComponet_advertised_post.DataSource = dataTable;
            this.ddlComponet_advertised_post.DataTextField = "Sub_Directorate_Name";
            this.ddlComponet_advertised_post.DataValueField = "Sub_Directorate_id";
            this.ddlComponet_advertised_post.DataBind();
            this.ddlComponet_advertised_post.Items.Insert(0, "Select One...");

            txtComponent.Visible = false;
            ddlComponet_advertised_post.Visible = true;
        }
        else if (dataTable.Rows.Count == 0)
        {
            ddlComponet_advertised_post.Items.Clear();

            ddlComponet_advertised_post.Enabled = false;
            ddlComponet_advertised_post.DataTextField = "N/A";
            ddlComponet_advertised_post.DataValueField = "N/A";
            this.ddlComponet_advertised_post.DataBind();
            this.ddlComponet_advertised_post.Items.Insert(0, "N/A");

            txtComponent.Text = "";
        }
        sqlcon3.Close();

    }

    public void countRows()
    {
        sqlcon3 = new SqlConnection(Conn);

        sqlcon3.Open();
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) as Tot FROM [dbo].[PostDetails]", sqlcon3);

        SqlDataReader dr;

        dr = cmd.ExecuteReader();

        while (dr.Read())
        {
            count = Convert.ToInt32(dr["tot"]);
        }
        dr.Close();
        sqlcon3.Close();
    }
    public void generateRef(int tot)
    {
        try
        {
            if (ddlDirectorate_advertised_post.Visible == false)
            {
                BU = txtDirectorate.Text;
            }
            else
            {
                BU = ddlDirectorate_advertised_post.SelectedItem.Text;
            }

            SqlCommand cmd = new SqlCommand("select abbreviation from Directorates where Directorate_Name = '" + BU + "'", sqlcon3);

            this.sqlcon3.ConnectionString = this.Conn;
            cmd.Connection = this.sqlcon3;
            sqlcon3.Open();

            SqlDataReader dr;

            dr = cmd.ExecuteReader();


            while (dr.Read())
            {
                string name = dr["abbreviation"].ToString();
                string refNo;

                if (count > 0 && count < 9)
                {
                    int j = count + 1;

                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + "0" + j.ToString();

                    txtPostRefNo.Text = refNo;
                }
                else if (count >= 9)
                {
                    int j = count + 1;

                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + j.ToString();

                    txtPostRefNo.Text = refNo;

                }
                else if (count == 0)
                {
                    refNo = "DRT" + "/" + name.ToUpper() + "/" + DateTime.Today.Year + "/" + "01";

                    txtPostRefNo.Text = refNo;
                }

            }
        }
        catch
        {

        }

        sqlcon3.Close();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            ValiadateControls();
            string agency = "";

            foreach (ListItem item in ListBox1.Items)
            {
                if (item.Selected)
                {
                    agency += item.Text + ",";

                }

            }

            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "UpdatePostDetails";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@post_id", SqlDbType.VarChar).Value = HiddenField_postID.Value;
            cmd.Parameters.Add("@Branch_advertised_post", SqlDbType.VarChar).Value = ddlBranch_advertised_post.SelectedItem.Text;
            if (ddlChief_Directorate_advertised_post.Visible == true)
            {
                cmd.Parameters.Add("@Chief_Directorate_advertised_post", SqlDbType.VarChar).Value = ddlChief_Directorate_advertised_post.SelectedItem.Text;
            }
            else
            {
                cmd.Parameters.Add("@Chief_Directorate_advertised_post", SqlDbType.VarChar).Value = txtChiefDirectorate.Text;
            }

            if (ddlDirectorate_advertised_post.Visible == true)
            {
                cmd.Parameters.Add("@Directorate_advertised_post", SqlDbType.VarChar).Value = ddlDirectorate_advertised_post.SelectedItem.Text;
            }
            else
            {
                cmd.Parameters.Add("@Directorate_advertised_post", SqlDbType.VarChar).Value = txtDirectorate.Text;
            }

            if (ddlComponet_advertised_post.Visible == true)
            {
                cmd.Parameters.Add("@Sub_Directorate", SqlDbType.VarChar).Value = ddlComponet_advertised_post.SelectedItem.Text;
            }
            else
            {
                cmd.Parameters.Add("@Sub_Directorate", SqlDbType.VarChar).Value = txtComponent.Text;
            }
            cmd.Parameters.Add("@post_applied", SqlDbType.VarChar).Value = txtPostApplied.Text;

            cmd.Parameters.Add("@Post_ref_no", SqlDbType.VarChar).Value = txtPostRefNo.Text;

            if (ddlPostLevel.Enabled == false && ddlOSD.SelectedItem.Text == "OSD")
            {
                if (ddlOSDPost_grade.Visible == true)
                {
                    cmd.Parameters.Add("@Post_Level", SqlDbType.VarChar).Value = ddlOSDPost_grade.SelectedItem.Text;
                }
                else
                {
                    cmd.Parameters.Add("@Post_Level", SqlDbType.VarChar).Value = txtOSD_post_grade.Text;
                }
            }
            else
            {
                cmd.Parameters.Add("@Post_Level", SqlDbType.VarChar).Value = ddlPostLevel.Text;
            }

            cmd.Parameters.Add("@vacant_filled", SqlDbType.VarChar).Value = ddlVacantorFilled.Text;
            cmd.Parameters.Add("@Post_Salary_Notch", SqlDbType.Decimal).Value = Convert.ToDecimal(txtPostSalaryNotch.Text);
            cmd.Parameters.Add("@post_date_advertised", SqlDbType.DateTime).Value = dpPostDateAdvertised.Text;
            cmd.Parameters.Add("@post_closing_date", SqlDbType.DateTime).Value = dpPostClosingDate.Text;

            cmd.Parameters.Add("@media_public_date", SqlDbType.DateTime).Value = dpMediaPublicDate.Text;

            cmd.Parameters.Add("@advertising_agency", SqlDbType.VarChar).Value = agency.TrimEnd(',');
            cmd.Parameters.Add("@cost_of_advert", SqlDbType.VarChar).Value = txtCostOfAdvert.Text;
            cmd.Parameters.Add("@response_handling", SqlDbType.VarChar).Value = ddlResponse.SelectedItem.Text;
            cmd.Parameters.Add("@OSD_or_non_OSD", SqlDbType.VarChar).Value = ddlOSD.SelectedValue;
            cmd.Parameters.Add("@no_of_posts", SqlDbType.VarChar).Value = txtNoOfPosts.Text;

            //cmd.Parameters.Add("@date_cv_released", SqlDbType.DateTime).Value = dpDateCvReleased.Text;

            if (ddlVacantorFilled.SelectedValue == "Vacant")
            {
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = "";
            }
            else if (ddlVacantorFilled.SelectedValue == "Filled")
            {
                cmd.Parameters.Add("@Comments", SqlDbType.VarChar).Value = txtComments.Text;
            }

            cmd.Parameters.Add("@date_post_created", SqlDbType.DateTime).Value = dpPostDateCreated.Text;
            cmd.Parameters.Add("@InternalOrExternal", SqlDbType.VarChar).Value = ddlExtOrInt.SelectedValue;

            if (ddlOSD.SelectedItem.Text == "OSD")
            {
                cmd.Parameters.Add("@OSD_Category", SqlDbType.VarChar).Value = ddlOSDCategory.SelectedItem.Text;
            }
            else if (ddlOSD.SelectedItem.Text == "Non-OSD")
            {
                cmd.Parameters.Add("@OSD_Category", SqlDbType.VarChar).Value = DBNull.Value;
            }

            sqlcon.Open();

            cmd.ExecuteNonQuery();

            sqlcon.Close();
            ShowMessage("Post Details Updated Successfully");
        }
        catch
        {


        }
    }

    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Post Details Updated Successfully');window.location.href='Home.aspx';('" + message + "')</script>");

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void ddlVacantorFilled_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlVacantorFilled.SelectedValue == "Vacant")
        {
            txtComments.Visible = false;
            lblComments.Visible = false;
        }
        else if (ddlVacantorFilled.SelectedValue == "Filled")
        {
            lblComments.Visible = true;
            txtComments.Visible = true;
        }
    }
    protected void ddlExtOrInt_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlExtOrInt.SelectedValue == "Internal")
        {
            txtPostRefNo.Enabled = false;

            //generateRef2(count);
            generateRef(count);

        }
        else if (ddlExtOrInt.SelectedValue == "External")
        {
            txtPostRefNo.Enabled = true;
            txtPostRefNo.Text = string.Empty;
            txtPostRefNo.Focus();
        }
        else
        {
           
            Message("Please specify if post is Internal or External");
        }
    }

    public void LoadAgencies()
    {
        SqlCommand Command = new SqlCommand("SELECT * from advertising_agency");
        this.sqlcon2.ConnectionString = this.Conn;
        Command.Connection = this.sqlcon2;
        SqlDataAdapter adapter = new SqlDataAdapter(Command);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ListBox1.DataSource = dataTable;
            this.ListBox1.DataTextField = "advertising_agency_name";
            this.ListBox1.DataValueField = "advertising_agency_id";
            this.ListBox1.DataBind();

        }
    }
    protected void txtCostOfAdvert_TextChanged(object sender, EventArgs e)
    {
        if (txtCostOfAdvert.Text != "")
        {
            try
            {
                decimal iCost = Convert.ToDecimal(txtCostOfAdvert.Text);

                string sCost = iCost.ToString("#,##0.00");
                txtCostOfAdvert.Text = sCost.ToString();
            }
            catch
            {
               
                Message("Please select response handling!!!");

                txtCostOfAdvert.Text = string.Empty;
                txtCostOfAdvert.Focus();
            }
        }
    }
    protected void ddlPostLevel_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSD.SelectedIndex != 0)
        {
            NonOSDsalaryNotch();
        }
        else
        {
            
            Message("Please Specify if Post is OSD or Non-OSD!!!!");

        }
    }
    public void NonOSDsalaryNotch()
    {
        try
        {
            sqlcon4 = new SqlConnection(Conn);
            String sql = "Select * from salary_scale where post_level = '" + ddlPostLevel.SelectedValue + "' ";
            sqlcon4.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon4);
            SqlDataReader dr = sqlcmd.ExecuteReader();


            while (dr.Read())
            {

                decimal salary = Convert.ToDecimal(dr["non-OSD_salary_notch"]);
                txtPostSalaryNotch.Text = salary.ToString("#,##0.00");


            }
            sqlcon4.Close();

            ddlOSDPost_grade.SelectedIndex = 0;
            ddlOSDCategory.SelectedIndex = 0;
        }
        catch
        {

        }
    }


    public void LoadOSDcategory()
    {
        SqlCommand selectCommand = new SqlCommand("select * from OSD_categories");
        this.sqlcon4.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlOSDCategory.DataSource = dataTable;
            this.ddlOSDCategory.DataTextField = "category_name";
            this.ddlOSDCategory.DataValueField = "category_id";
            this.ddlOSDCategory.DataBind();
            this.ddlOSDCategory.Items.Insert(0, "Select One...");

        }
        sqlcon4.Close();
    }

    public void LoadOSDpost_grade()
    {
        SqlCommand cmd = new SqlCommand("select * from [dbo].[OSD_posts_and_grades] where category_id = '" + ddlOSDCategory.SelectedValue + "'");
        this.sqlcon4.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon4;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlOSDPost_grade.DataSource = dataTable;
            this.ddlOSDPost_grade.DataTextField = "OSD_post_name";
            this.ddlOSDPost_grade.DataValueField = "OSD_post_id";
            this.ddlOSDPost_grade.DataBind();
            this.ddlOSDPost_grade.Items.Insert(0, "Select One...");
        }
        sqlcon4.Close();
    }

    public void OSDsalaryNotch()
    {
        try
        {
            sqlcon4 = new SqlConnection(Conn);
            String sql = "Select OSD_salary_notch from [dbo].[OSD_posts_and_grades] where category_id = '" + ddlOSDCategory.SelectedValue + "' and OSD_post_id = '" + ddlOSDPost_grade.SelectedValue + "' ";
            sqlcon4.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon4);
            SqlDataReader dr = sqlcmd.ExecuteReader();


            while (dr.Read())
            {
                decimal salary = Convert.ToDecimal(dr["OSD_salary_notch"]);
                txtPostSalaryNotch.Text = salary.ToString("#,##0.00");

            }
            sqlcon4.Close();

            ddlPostLevel.SelectedIndex = 0;

        }
        catch
        {

        }


    }
    protected void ddlOSD_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlOSD.SelectedValue == "Non-OSD")
        {
            ddlOSDCategory.Items.Clear();

            txtOSD_post_grade.Text = string.Empty;

            ddlOSDCategory.Enabled = false;

            ddlOSDPost_grade.Enabled = false;
            ddlOSDPost_grade.Items.Clear();

            ddlPostLevel.Enabled = true;

            txtPostSalaryNotch.Text = string.Empty;
            ddlPostLevel.SelectedIndex = 0;


        }
        else if (ddlOSD.SelectedValue == "OSD")
        {
            ddlPostLevel.Enabled = false;

            ddlOSDCategory.Enabled = true;
            ddlOSDPost_grade.Enabled = false;

            ddlPostLevel.SelectedIndex = 0;
            txtPostSalaryNotch.Text = string.Empty;

            LoadOSDcategory();
        }
        else
        {
            
            Message("Please Specify if Post is OSD or Non-OSD!!!!");

            ddlPostLevel.SelectedIndex = 0;
        }
    }
    protected void ddlOSDCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            if (ddlOSD.SelectedItem.Text != "Select One...")
            {
                if (ddlOSDCategory.SelectedItem.Text != "Select One...")
                {
                    ddlOSDPost_grade.Visible = true;
                    ddlOSDPost_grade.Enabled = true;
                    txtOSD_post_grade.Visible = false;
                    LoadOSDpost_grade();
                }
                else
                {
                    
                    Message("Please Select OSD Category!!!!");
                }
            }


            else
            {
                
                Message("Please Specify if Post is OSD or Non-OSD!!!!!");
            }
        }
        catch
        {

        }

    }
    protected void ddlOSDPost_grade_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlOSDCategory.SelectedItem.Text != "Select One...")
            {

                if (ddlOSDPost_grade.SelectedItem.Text != "Select One..." && ddlOSDCategory.SelectedIndex != 0)
                {
                    OSDsalaryNotch();
                }
                else if (ddlOSDPost_grade.SelectedIndex == 0)
                {
                   
                    Message("Please select OSD Post/Grade!!!");
                }
            }
            else
            {
                
                Message("Please select OSD category!!!");
            }
        }
        catch
        {

        }
    }

    protected void txtOSD_post_grade_TextChanged(object sender, EventArgs e)
    {
        if (ddlOSDCategory.SelectedItem.Text == "Select One...")
        {
            
            Message("Please select OSD Category!!");
        }
        else if (ddlOSDPost_grade.SelectedItem.Text == "Select One...")
        {
           
            Message("Please select OSD Post/Grade!!");
        }

    }
    protected void ddlDirectorate_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDirectorate_advertised_post.SelectedIndex != 0)
        {
            this.LoadSub_Directorate(Convert.ToInt32(ddlDirectorate_advertised_post.SelectedValue));
            ddlComponet_advertised_post.Enabled = true;
            //txtPostRefNo.Enabled = true;
            txtPostRefNo.Text = "";
            ddlExtOrInt.SelectedIndex = 0;
        }
        else if (ddlChief_Directorate_advertised_post.Text == "Select One...")
        {
            ddlDirectorate_advertised_post.Enabled = false;
            ddlChief_Directorate_advertised_post.Enabled = false;
            ddlComponet_advertised_post.Enabled = false;
                        
            Message("Please select Chief Directorate!!!!");
        }
        else
        {
            ddlComponet_advertised_post.Enabled = false;            
            Message("Please select Directorate!!!!");
        }
    }
    protected void ddlBranch_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlBranch_advertised_post.SelectedIndex != 0)
        {
            ddlChief_Directorate_advertised_post.Items.Clear();
            ddlChief_Directorate_advertised_post.Enabled = true;
            ddlDirectorate_advertised_post.Items.Clear();

            this.LoadChief_Directorate(Convert.ToInt32(ddlBranch_advertised_post.SelectedValue));

            ddlChief_Directorate_advertised_post.Visible = true;
            txtChiefDirectorate.Visible = false;

            ddlDirectorate_advertised_post.Enabled = false;
            ddlComponet_advertised_post.Items.Clear();
            ddlComponet_advertised_post.Enabled = false;
        }
        //else
        //{
        //    //ddlChief_Directorate_advertised_post.Items.Clear();
        //    ddlChief_Directorate_advertised_post.Enabled = false;
        //    ddlDirectorate_advertised_post.Enabled = false;
        //    ddlComponet_advertised_post.Enabled = false;

           
        //    //Message("Please select Branch!!!!");
        //}
    }
    protected void ddlChief_Directorate_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlChief_Directorate_advertised_post.SelectedIndex != 0)
        {
            this.LoadDirectorate(Convert.ToInt32(ddlChief_Directorate_advertised_post.SelectedValue));
            ddlDirectorate_advertised_post.Enabled = true;
            ddlComponet_advertised_post.Enabled = false;
            txtDirectorate.Visible = false;
            ddlDirectorate_advertised_post.Visible = true;
        }
        else if (ddlBranch_advertised_post.Text == "Select One...")
        {
           
            Message("Please select Branch!!!!");
        }
        else
        {
            ddlComponet_advertised_post.Enabled = false;
            ddlDirectorate_advertised_post.Enabled = false;

          
            Message("Please select Chief Directorate!!!!");
        }
    }
    protected void ddlComponet_advertised_post_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlComponet_advertised_post.SelectedItem.Text == "Select One...")
        {
           
            Message("Please select Component!!!!!");
        }
    }

    public void ValiadateControls()
    {
        if (ddlResponse.SelectedItem.Text == "Select One...")
        {
            
            Message("Please select response handling!!!");
            return;
        }
        else if (dpMediaPublicDate.Text == "")
        {
            
            Message("Please select response handling!!!");
            return;
        }
        else if (dpPostClosingDate.Text == "")
        {
            
            Message("Please select post closing date!!!");
            return;
        }
        else if (dpPostDateAdvertised.Text == "")
        {
           
            Message("Please select date post advertised!!!");
            return;
        }
        else if (dpPostDateCreated.Text == "")
        {
            Message("Please select date post created!!!");        

            return;
        }

    }

    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                   "alert('" + msg + "');", true);
    }

    protected void RangeValidator_Init(object sender, EventArgs e)
    {
        ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();


    }
}