﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Administrator_Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();

    DateTime startdate = DateTime.Today.Date;
    DateTime end_date = DateTime.Today.Date;   

    protected void Page_Load(object sender, EventArgs e)
    {
       
         //BindGridview();         
       
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }

public void BindGridview()
{
    try
    {
        if (txtEndDate.Text == string.Empty || txtStartDate.Text == string.Empty)
        {


            SqlCommand cmd = new SqlCommand(Conn);
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "ReportFullDataAdverts";
            cmd.CommandType = CommandType.StoredProcedure;


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            //GridView1.FooterRow.Cells[2].Text = "Total Posts";
            //GridView1.FooterRow.Cells[5].Text = dt.Compute("Sum(no_of_posts)", "").ToString();
            sqlcon.Close();
        }
        else
        {

            SqlCommand cmd = new SqlCommand(Conn);
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "ReportFullDataAdvertsSearch";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@start_date", SqlDbType.DateTime).Value = startdate;
            cmd.Parameters.Add("@end_date", SqlDbType.DateTime).Value = end_date;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

            sqlcon.Close();
        }
       
    }
    catch
    {
        Message("Error!!! Please contact system administrator");
    }
}  
    


public void Message( string msg)
{
    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
               "alert('" + msg + "');", true);
}


protected void btnExport_Click(object sender, EventArgs e)
{
    try
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.ClearHeaders();
        HttpContext.Current.Response.Charset = "";
        string FileName = "RSS_Report_Summary_Per_Component_Adverts_.xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        GridView1.GridLines = GridLines.Both;
        GridView1.HeaderStyle.Font.Bold = true;
        GridView1.RenderControl(htmltextwrtter);
        HttpContext.Current.Response.Write(strwritter.ToString());
        HttpContext.Current.Response.End();
        System.Web.HttpContext.Current.ApplicationInstance.CompleteRequest();
        
    }
    catch
    {
        Message("Error!!! Please contact system administrator");
    }
}

protected void OnPaging(object sender, GridViewPageEventArgs e)
{
    
    GridView1.PageIndex = e.NewPageIndex;
    GridView1.DataBind();
    BindGridview();
}
public void BindDate()
{
    

}

protected void btnSearch_Click(object sender, EventArgs e)
{
    try
    {
        if (txtEndDate.Text != string.Empty && txtStartDate.Text != string.Empty)
        {
            try
            {
                startdate = Convert.ToDateTime(txtStartDate.Text);
                end_date = Convert.ToDateTime(txtEndDate.Text);

                if (startdate > end_date && startdate > DateTime.Today)
                {
                    Message("Please enter valid start date");
                }
            }
            catch
            {
                Message("Please enter valid dates");
            }
            BindGridview();
        }
        else
        {
            Message("Please enter start date and end date");
        }
    }
    catch
    {
        Message("Error:");
    }
}

protected void btnSearchAll_Click(object sender, EventArgs e)
{
    txtStartDate.Text = string.Empty;
    txtEndDate.Text = string.Empty;

    try
    {
        BindGridview();
    }
    catch
    {
        Message("Error:");
    }
}
}