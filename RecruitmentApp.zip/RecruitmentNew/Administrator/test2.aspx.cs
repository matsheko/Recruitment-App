﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _test2 : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    //int id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {                   
           
            bindGriview();
        }
    }
    private void bindGriview()
    {
        sqlcon.Close();

        SqlCommand cmd2 = new SqlCommand("select * from interview_panel where post_reference = '10333' and interview_id = '19' ");
        this.sqlcon.ConnectionString = this.Conn;
        cmd2.Connection = this.sqlcon;
        
        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);
        GridView1.DataSource = dt2;
        GridView1.DataBind();

        sqlcon.Close();
    }

    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(Conn);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        return dt;
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bindGriview();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void AddNewCustomer(object sender, EventArgs e)
    {
        int interviewID = 19;
        string postRef = "10333";

        string names = ((TextBox)GridView1.FooterRow.FindControl("txtName_Surname")).Text;
        string rank = ((TextBox)GridView1.FooterRow.FindControl("txtRank")).Text;
        string designation = ((TextBox)GridView1.FooterRow.FindControl("txtDesignation")).Text;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into interview_panel(post_reference,interview_id,names, rank, designation) " + "values(@post_reference,@interview_id,@names, @rank, @designation)";

        cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = postRef;
        cmd.Parameters.Add("@interview_id", SqlDbType.Int).Value = interviewID;
        cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
        cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
        cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();


        bindGriview();
    }

    protected void DeleteCustomer(object sender, EventArgs e)
    {


        LinkButton lnkRemove = (LinkButton)sender;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from  interview_panel where " + "id=@id";
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = lnkRemove.CommandArgument;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
    protected void EditCustomer(object sender, GridViewEditEventArgs e)
    {


        GridView1.EditIndex = e.NewEditIndex;
        bindGriview();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bindGriview();
    }
    protected void UpdateCustomer(object sender, GridViewUpdateEventArgs e)
    {
              
        int id = Convert.ToInt32( ((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text);
        

        string names =  ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtName_Surname")).Text;
        string rank = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtRank")).Text;
        string designation = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDesignation")).Text;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "update interview_panel set names=@names,rank=@rank,designation=@designation " + "where id=@id";
        cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
        cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
        cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
        cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
        GridView1.EditIndex = -1;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
}
