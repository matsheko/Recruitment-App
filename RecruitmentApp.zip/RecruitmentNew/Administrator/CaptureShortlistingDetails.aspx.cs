﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections;
using System.Collections.Specialized;


public partial class _Default : System.Web.UI.Page
{
    ArrayList arraylist1 = new ArrayList();
    ArrayList arraylist2 = new ArrayList();

    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    SqlConnection sqlcon3 = new SqlConnection();   

    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            SetInitialRow();

            CVsReceived();

            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            sqlcon.Open();

            cmd.CommandText = "BindListbox";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@post_reference", Request["id"].ToString());            

            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            
            DataTable dt = new DataTable();        
                        
            adp.Fill(dt);

            ListBox1.DataSource = dt;
            ListBox1.DataTextField = "FullName";
            ListBox1.DataValueField = "idPassport";
            ListBox1.DataBind();

            
            if (ListBox1.Items.Count == 0)
            {

                MesageBox("No applications associated with this Reference number!!!!", ResolveUrl("~/Administrator/Home.aspx"));
            }
        }
           
    }
    public void CVsReceived()
    {
        sqlcon3 = new SqlConnection(Conn);

        sqlcon3.Open();
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) as CVs FROM [dbo].[applicants] where post_reference = '"+ Request["id"] +"'", sqlcon3);
       
        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
            txtNoOfCVRecieved.Text = dr["CVs"].ToString();
            txtNoOfCvReleased.Text = dr["CVs"].ToString(); 
        }
        dr.Close();
        sqlcon3.Close();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        ValiadateControls();
         try
            {
                string PostRef = Request["id"].ToString();

                bool exists = false;

                using (SqlCommand cmd2 = new SqlCommand("select count(*) from shortlisting_commitee where post_reference = '" + PostRef + "' "))
                {
                    cmd2.Parameters.AddWithValue("post_reference", PostRef);
                    this.sqlcon2.ConnectionString = this.Conn;
                    cmd2.Connection = this.sqlcon2;

                    sqlcon2.Open();
                    exists = (int)cmd2.ExecuteScalar() > 0;
                    sqlcon2.Close();
                }
                if (exists)
                {

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                          "alert('Shortlisting details with this Reference Number already exist');", true);
                }
                else
                {


                    SqlCommand cmd = new SqlCommand();
                    sqlcon.ConnectionString = Conn;
                    cmd.Connection = sqlcon;


                    string CandidateName = "";
                    string idPassport = "";


                    IList<string> items = new List<string>();

                    foreach (ListItem item in ListBox2.Items)
                    {
                        items.Add(item.Text);

                        CandidateName += item.Text + ",";

                        idPassport += item.Value + ",";
                    }


                    cmd.CommandText = "insertShortlistingCommitee";
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@shortlising_date", SqlDbType.DateTime).Value = DateTime.ParseExact(dpShortlistingDate.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture);
                    cmd.Parameters.Add("@comments", SqlDbType.VarChar).Value = txtComments.Text;               
                
                    cmd.Parameters.Add("@date_CVs_received", SqlDbType.DateTime).Value = DateTime.ParseExact(dpDateCVsReceived.Text, "yyyy/MM/dd", CultureInfo.InvariantCulture);                  
                    cmd.Parameters.Add("@no_of_CVs_received", SqlDbType.Int).Value = Convert.ToInt32(txtNoOfCVRecieved.Text);
                    cmd.Parameters.Add("@no_of_CVs_released", SqlDbType.Int).Value = Convert.ToInt32(txtNoOfCvReleased.Text);
                    cmd.Parameters.Add("@shortlistedCandidates", SqlDbType.VarChar).Value = CandidateName.TrimEnd(',');
                    cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = Request.QueryString["id"];

                    cmd.Parameters.Add("@idPassport", SqlDbType.VarChar).Value = idPassport.TrimEnd(',');

                    cmd.Parameters.Add("@NewId", SqlDbType.Int).Direction = ParameterDirection.Output;

                    sqlcon.Open();
                    cmd.ExecuteNonQuery();

                    int num = Convert.ToInt32(cmd.Parameters["@NewId"].Value);
                    this.Session["shortlisting_id"] = num;

                    //Save to the shortlisting committe names table
                    int rowIndex = 0;
                    StringCollection sc = new StringCollection();
                    if (ViewState["CurrentTable"] != null)
                    {
                        DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                        if (dtCurrentTable.Rows.Count > 0)
                        {
                            for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                            {
                                //extract the TextBox values
                                TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                                TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");
                                TextBox box3 = (TextBox)GridView1.Rows[rowIndex].Cells[2].FindControl("txtDesignation");

                                //get the values from the TextBoxes
                                //then add it to the collections with a comma "," as the delimited values
                                sc.Add(box1.Text + "," + box2.Text + "," + box3.Text + "," + this.Session["shortlisting_id"].ToString() + "," + Request.QueryString["ID"].ToString());
                                rowIndex++;
                            }


                            //Call the method for executing inserts
                            InsertRecords(sc);
                        }
                    }
                    sqlcon.Close();
                    ShowMessage("Shortlisting Details Successfully captured");

                }
            }
         catch
         {


         }
    }
     
    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Shortlisting Details Successfully captured');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        while (ListBox1.Items.Count != 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {
                ListBox2.Items.Add(ListBox1.Items[i]);
                ListBox1.Items.Remove(ListBox1.Items[i]);
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

        if (ListBox1.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {
                if (ListBox1.Items[i].Selected)
                {
                    if (!arraylist1.Contains(ListBox1.Items[i]))
                    {
                        arraylist1.Add(ListBox1.Items[i]);
                    }
                }
            }
            for (int i = 0; i < arraylist1.Count; i++)
            {
                if (!ListBox2.Items.Contains(((ListItem)arraylist1[i])))
                {
                    ListBox2.Items.Add(((ListItem)arraylist1[i]));
                }
                ListBox1.Items.Remove(((ListItem)arraylist1[i]));
            }
            ListBox2.SelectedIndex = -1;
        }
        else
        {

            //Response.Write("Please select atleast one in Listbox1 to move");
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {

        while (ListBox2.Items.Count != 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                ListBox1.Items.Add(ListBox2.Items[i]);
                ListBox2.Items.Remove(ListBox2.Items[i]);
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (ListBox2.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                if (ListBox2.Items[i].Selected)
                {
                    if (!arraylist2.Contains(ListBox2.Items[i]))
                    {
                        arraylist2.Add(ListBox2.Items[i]);
                    }
                }
            }
            for (int i = 0; i < arraylist2.Count; i++)
            {
                if (!ListBox1.Items.Contains(((ListItem)arraylist2[i])))
                {
                    ListBox1.Items.Add(((ListItem)arraylist2[i]));
                }
                ListBox2.Items.Remove(((ListItem)arraylist2[i]));
            }
            ListBox1.SelectedIndex = -1;
        }
        else
        {
            //Response.Write("Please select atleast one in Listbox2 to move");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    private void InsertRecords(StringCollection sc)
    {
        SqlConnection Sqlconn = new SqlConnection();
        Sqlconn.ConnectionString = Conn;
        StringBuilder sb = new StringBuilder(string.Empty);
        string[] splitItems = null;
        foreach (string item in sc)
        {

            const string sqlStatement = "INSERT INTO shortlisting_committee_names (names,rank,designation,shortlisting_id,post_reference) VALUES";
            if (item.Contains(","))
            {
                splitItems = item.Split(",".ToCharArray());
                sb.AppendFormat("{0}('{1}','{2}','{3}','{4}','{5}'); ", sqlStatement, splitItems[0], splitItems[1], splitItems[2], splitItems[3], splitItems[4]);
            }

        }

        try
        {
            
            Sqlconn.Open();
            SqlCommand cmd = new SqlCommand(sb.ToString(), Sqlconn);

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            //Display a popup which indicates that the record was successfully inserted
            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Script", "alert('Records Successfuly Saved!');", true);

        }
        catch (System.Data.SqlClient.SqlException ex)
        {
            string msg = "Insert Error:";
            msg += ex.Message;
            throw new Exception(msg);

        }
        finally
        {
            Sqlconn.Close();
        }
    }
    private void AddNewRowToGrid()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
            DataRow drCurrentRow = null;
            if (dtCurrentTable.Rows.Count > 0)
            {
                for (int i = 1; i <= dtCurrentTable.Rows.Count; i++)
                {
                    //extract the TextBox values
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");
                    DropDownList box3 = (DropDownList)GridView1.Rows[rowIndex].Cells[2].FindControl("ddlDesignation");
                    drCurrentRow = dtCurrentTable.NewRow();
                    dtCurrentTable.Rows[i - 1]["Column1"] = box1.Text;
                    dtCurrentTable.Rows[i - 1]["Column2"] = box2.Text;
                    dtCurrentTable.Rows[i - 1]["Column3"] = box3.SelectedItem.Text;

                    rowIndex++;
                }

                dtCurrentTable.Rows.Add(drCurrentRow);
                ViewState["CurrentTable"] = dtCurrentTable;

                GridView1.DataSource = dtCurrentTable;
                GridView1.DataBind();
            }
        }
        else
        {
            Response.Write("ViewState is null");
        }

        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    private void SetPreviousData()
    {
        int rowIndex = 0;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    TextBox box1 = (TextBox)GridView1.Rows[rowIndex].Cells[0].FindControl("txtName_Surname");
                    TextBox box2 = (TextBox)GridView1.Rows[rowIndex].Cells[1].FindControl("txtRank");
                    DropDownList box3 = (DropDownList)GridView1.Rows[rowIndex].Cells[2].FindControl("ddlDesignation");

                    //Fill the DropDownList with Data
                    FillDropDownList(box3);
                    box1.Text = dt.Rows[i]["Column1"].ToString();
                    box2.Text = dt.Rows[i]["Column2"].ToString();
                    //box3.SelectedItem.Text = dt.Rows[i]["Column3"].ToString();
                    if (i < dt.Rows.Count - 1)
                    {
                        box3.ClearSelection();
                        box3.Items.FindByText(dt.Rows[i]["Column3"].ToString()).Selected = true;
                    }
                    rowIndex++;
                }
            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton lb = (LinkButton)sender;
        GridViewRow gvRow = (GridViewRow)lb.NamingContainer;
        int rowID = gvRow.RowIndex + 1;
        if (ViewState["CurrentTable"] != null)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            if (dt.Rows.Count > 1)
            {
                if (gvRow.RowIndex < dt.Rows.Count - 1)
                {
                    //Remove the Selected Row data
                    dt.Rows.Remove(dt.Rows[rowID]);
                }
            }
            //Store the current data in ViewState for future reference
            ViewState["CurrentTable"] = dt;
            //Re bind the GridView for the updated data
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        //Set Previous Data on Postbacks
        SetPreviousData();
    }
    private void SetInitialRow()
    {
        DataTable dt = new DataTable();
        DataRow dr = null;
        //dt.Columns.Add(new DataColumn("RowNumber", typeof(string)));
        dt.Columns.Add(new DataColumn("Column1", typeof(string)));
        dt.Columns.Add(new DataColumn("Column2", typeof(string)));
        dt.Columns.Add(new DataColumn("Column3", typeof(string)));
        dr = dt.NewRow();
        //dr["RowNumber"] = 1;
        dr["Column1"] = string.Empty;
        dr["Column2"] = string.Empty;
        dr["Column3"] = string.Empty;
        dt.Rows.Add(dr);
        //dr = dt.NewRow();

        //Store the DataTable in ViewState
        ViewState["CurrentTable"] = dt;

        GridView1.DataSource = dt;
        GridView1.DataBind();
        DropDownList ddl3 = (DropDownList)GridView1.Rows[0].Cells[3].FindControl("ddlDesignation");
        FillDropDownList(ddl3);
    }
    private ArrayList GetDummyData()
    {
        ArrayList arr = new ArrayList();
        arr.Add(new ListItem("Chairperson", "1"));
        arr.Add(new ListItem("Panel Member", "2"));
        arr.Add(new ListItem("Union Representative", "3"));
        arr.Add(new ListItem("HR Representative", "4"));
        return arr;
    }
    private void FillDropDownList(DropDownList ddl)
    {
        ArrayList arr = GetDummyData();
        foreach (ListItem item in arr)
        {
            ddl.Items.Add(item);
        }
    }
    protected void ButtonAdd_Click(object sender, EventArgs e)
    {
        AddNewRowToGrid();
    }
    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        
    }
    
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    public void MesageBox(string mgs, string url)
    {
        string script = "window.onload = function(){ alert('";
        script += mgs;
        script += "');";
        script += "window.location = '";
        script += url;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
    }

    public void ValiadateControls()
    {
        if (ListBox2.Items.Count == 0)
        {
            Message("Please select shortlisted candidates");
            //ListBox1.Focus();
            return;
        }
        else if (dpShortlistingDate.Text == "")
        {
            Message("Please select shortlisting date");
            dpShortlistingDate.Focus();
            return;
        }
        else if (Convert.ToDateTime(dpShortlistingDate.Text) > DateTime.Today)
        {
            Message("Shortlistening date cannot be a future date");
            dpShortlistingDate.Focus();
            return;
        }
        else if (dpDateCVsReceived.Text == "")
        {
            Message("Please select date CVs Received");
            dpDateCVsReceived.Focus();
           
            return;
        }
        else if (txtComments.Text == "")
        {
            Message("Please enter comments");
            txtComments.Focus();
            return;
        }    
        if (Convert.ToDateTime(dpDateCVsReceived.Text) > DateTime.Today)
        {
            Message("Date CVs received cannot be a future date");
            dpDateCVsReceived.Focus();
           
            return;           
        }
       
          


    }
    public void Message(String msg)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                   "alert('" + msg + "');", true);
    }
    protected void RangeValidator_Init(object sender, EventArgs e)
    {
        ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();


    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataTable dt = (DataTable)ViewState["CurrentTable"];
            LinkButton lb = (LinkButton)e.Row.FindControl("LinkButton1");
            if (lb != null)
            {
                if (dt.Rows.Count > 1)
                {
                    if (e.Row.RowIndex == dt.Rows.Count - 1)
                    {
                        lb.Visible = false;
                    }
                }
                else
                {
                    lb.Visible = false;
                }
            }
        }
    }
}