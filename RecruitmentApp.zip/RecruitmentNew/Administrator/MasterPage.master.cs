﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;

        //if (Session.Count == 0)
        //{
        //    Response.Redirect("../session.aspx");
        //}
        //else
        //{
        //    lblUser.Text = Session["name"].ToString() + " " + Session["Surname"].ToString();

        //    if (Session["Role"].ToString() == "Normal User")
        //    {
        //        lbtnAdmin.Visible = false;
        //        lbtnReports.Visible = false;
        //        lbtnAdmin.Visible = false;
        //    }
        //    else if (Session["Role"].ToString() == "Manager")
        //    {
        //        lbtnAdmin.Visible = false;
        //        lbtnApplications.Visible = true;
        //        lbtnShortlisting.Visible = true;
        //        lbtnInterviews.Visible = true;
        //    }
        //}
    }
    protected void lbtnAgencies_Click(object sender, EventArgs e)
    {
        Response.Redirect("advertisingagencies.aspx");
    }
    protected void lbtnEditPost_Click(object sender, EventArgs e)
    {
        string pageName = LinkButton8.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }
    protected void lbtnEditDirectorate_Click(object sender, EventArgs e)
    {
        Response.Redirect("updatedirectorate.aspx");
    }
    protected void lbtnCreateDirectorate_Click(object sender, EventArgs e)
    {
        Response.Redirect("adddirectorate.aspx");
    }
    protected void lbtnAddCandidateDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnAddCandidateDetails.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }
    protected void lbtnEditCandidateDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnEditCandidateDetails.Text;

        Session["PageName"] = pageName;      

        Response.Redirect("search.aspx");
    }
    protected void lbtnCreateNewPost_Click(object sender, EventArgs e)
    {
       Response.Redirect("CapturePostDetails.aspx");
    }

    protected void lbtnCaptureInterviewDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnCaptureInterviewDetails.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }

    protected void lbtnUpdateInterviewDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnEditInterviewDetails.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }
    protected void lbtnCaptureShortlistingDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnCaptureShortlistingDetails.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }
    protected void lbtnEditShortlistingDetails_Click(object sender, EventArgs e)
    {
        string pageName = lbtnEditShortlistingDetails.Text;

        Session["PageName"] = pageName;

        Response.Redirect("search.aspx");
    }
    protected void lbtnCreateUser_Click(object sender, EventArgs e)
    {
        Response.Redirect("CreateUser.aspx");
    }
    protected void lbtnDirectorates_Click(object sender, EventArgs e)
    {

    }
    protected void lbtnSalaryNotches_Click(object sender, EventArgs e)
    {
        Response.Redirect("UpdateSalaryScales.aspx");
    }
    
    protected void lbtnEditUser_Click(object sender, EventArgs e)
    {
        Response.Redirect("searchusers.aspx");
    }
    protected void lbtnLogout_Click(object sender, EventArgs e)
    {
        if (Session["userID"] != null)
        {
            Session["Username"] = null;
            Session["Password"] = null;
            Session.Abandon();
            Response.Redirect("../default.aspx");
        }
    }
    protected void lbtnChangePass_Click(object sender, EventArgs e)
    {
        if (Session["username"] != null)
        {
            Response.Redirect("changepassword.aspx");
        }
    }

    protected void lbtnReportFullDataAdverts_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAdvertsFullData.aspx");
    }
    protected void lbtnReportSummaryPerComponentAdverts_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAdvertsSummaryPerComponent.aspx");
    }
    protected void lbtnReportExecutiveAdverts_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAdvertExecutiveSummary.aspx");
    }
    protected void lbtnReportDetailedSummaryAdverts_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAdvertDetailedSummary.aspx");
    }
    protected void lbtnReportFullDataAppointments_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAppointmentFullData.aspx");
    }
    protected void lbtnReportDetailedAppointments_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAppointmentDetailed.aspx");
    }
    protected void lbtnReportExecutiveAppointment_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAppointmentExecutive.aspx");
    }
    protected void lbtnUserReport_Click(object sender, EventArgs e)
    {
        Response.Redirect("ReportAdminUsers.aspx");
    }
}
