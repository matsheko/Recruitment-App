﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!base.IsPostBack)
        {
            ddlDepartment.Visible = true;
            txtBranch.Visible = false;
            txtBranch.Enabled = false;
            txtBranch.Focus();
            ddlBranch.Visible = false;
            //ddlChief_Directorate.Enabled = false;
            txtChiefDirectorate.Visible = false;
            ddlChief_Directorate.Visible = false;
            ddlDirectorate.Visible = false;
            txtDirectorate.Visible = false;
            txtSubDirectorate.Visible = false;
            btnAddChiefDirectorate.Visible = false;
            btnAddDirectorate.Visible = false;
            btnAddSubDirectorate.Visible = false;
            btnAddBranch.Visible = false;

            lblBranch.Visible = false;
            lblChiefDirectorate.Visible = false;
            lblDirectorate.Visible = false;
            lblSubDirectorate.Visible = false;
        }
    }

    protected void LoadBranch()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT branch_id, branch_name from branch");
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlBranch.DataSource = dataTable;
            this.ddlBranch.DataTextField = "branch_name";
            this.ddlBranch.DataValueField = "branch_id";
            this.ddlBranch.DataBind();
            //this.ddlBranch.Items.Insert(0, "Select one...");
        }
    }
    protected void LoadChief_Directorate(int branch_id)
    {
        SqlCommand cmd = new SqlCommand("SELECT Chief_Dire_id,Chief_Dire_Name from Chief_Directorate where Branch_ID = @Brach_id ORDER BY Chief_Dire_Name ASC ");
        cmd.Parameters.AddWithValue("@Brach_id", branch_id);
        this.sqlcon.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlChief_Directorate.DataSource = dataTable;
            this.ddlChief_Directorate.DataTextField = "Chief_Dire_Name";
            this.ddlChief_Directorate.DataValueField = "Chief_Dire_id";
            this.ddlChief_Directorate.DataBind();
            // this.ddlChief_Directorate.Items.Insert(0, "Select one...");
        }
    }
    protected void LoadDirectorate(int Chief_Dire_id)
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Directorate_id,Directorate_Name from Directorates where  Chief_Dire_ID = @Chief_Dire_id ORDER BY Directorate_Name ASC");
        selectCommand.Parameters.AddWithValue("@Chief_Dire_id", Chief_Dire_id);
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDirectorate.DataSource = dataTable;
            this.ddlDirectorate.DataTextField = "Directorate_Name";
            this.ddlDirectorate.DataValueField = "Directorate_id";
            this.ddlDirectorate.DataBind();
            //this.ddlDirectorate.Items.Insert(0, "Select one...");
        }
    }


    protected void btnAddBranch_Click(object sender, EventArgs e)
    {
        if (txtBranch.Text == string.Empty)
        {
            showMessage("Please enter branch name.");
        }
        else
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "insertBranch";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@branch_name", SqlDbType.NVarChar).Value = txtBranch.Text;

                sqlcon.Open();

                cmd.ExecuteNonQuery();

                sqlcon.Close();
                clear();
                Message("Successfully saved");
            }
            catch
            {
                showMessage("could not save branch.");
            }
        }
    }
    protected void btnAddChiefDirectorate_Click(object sender, EventArgs e)
    {
        if (txtChiefDirectorate.Text == string.Empty)
        {
            showMessage("Please enter Chief Directorate name.");
        }
        else
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "insertChief_Directorate";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Chief_Dire_Name", SqlDbType.NVarChar).Value = txtChiefDirectorate.Text;
                cmd.Parameters.Add("@Branch_id", SqlDbType.Int).Value = (Convert.ToInt32(ddlBranch.SelectedValue));

                sqlcon.Open();

                cmd.ExecuteNonQuery();

                sqlcon.Close();
                clear();
                Message("Successfully saved.");
            }
            catch
            {
                showMessage("could not save Chief direcetorate.");
            }
        }
    }
    protected void btnAddDirectorate_Click(object sender, EventArgs e)
    {
        if (txtDirectorate.Text == string.Empty)
        {
            showMessage("Please enter Directorate name.");
        }
        else
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "InsertDirectorates";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Directorate_Name", SqlDbType.NVarChar).Value = txtDirectorate.Text;
                cmd.Parameters.Add("@Chief_Dire_id", SqlDbType.Int).Value = (Convert.ToInt32(ddlChief_Directorate.SelectedValue));

                sqlcon.Open();

                cmd.ExecuteNonQuery();

                sqlcon.Close();
                clear();
                Message("Successfully saved.");
            }
            catch
            {
                showMessage("could not save Direcetorate.");
            }
        }
    }
    protected void btnAddSubDirectorate_Click(object sender, EventArgs e)
    {
        if (txtSubDirectorate.Text == string.Empty)
        {
            showMessage("Please enter Sub directorate name.");
        }
        else
        {
            try
            {

                SqlCommand cmd = new SqlCommand();
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "InsertSub_Directorate";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Sub_Directorate_Name", SqlDbType.NVarChar).Value = txtSubDirectorate.Text;
                cmd.Parameters.Add("@Directorate_id", SqlDbType.Int).Value = (Convert.ToInt32(ddlDirectorate.SelectedValue));

                sqlcon.Open();

                cmd.ExecuteNonQuery();

                sqlcon.Close();
                clear();
                //showMessage("Sub Direcetorate saved successfully.");
                Message("Successfully saved.");
            }
            catch
            {
                showMessage("could not save sub direcetorate.");
            }
        }
    
    }
    protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDepartment.SelectedIndex == 0)
        {
            clear();
            lblChiefDirectorate.Visible = false;
            lblDirectorate.Visible = false;
            lblSubDirectorate.Visible = false;
            lblBranch.Visible = false;
        }
        else if (ddlDepartment.SelectedIndex == 1)
        {
            txtBranch.Visible = true;
            txtBranch.Enabled = true;
            txtBranch.Focus();
            ddlBranch.Visible = false;
            //ddlChief_Directorate.Enabled = false;
            txtChiefDirectorate.Visible = false;
            ddlChief_Directorate.Visible = false;
            ddlDirectorate.Visible = false;
            txtDirectorate.Visible = false;
            txtSubDirectorate.Visible = false;
            btnAddChiefDirectorate.Visible = false;
            btnAddDirectorate.Visible = false;
            btnAddSubDirectorate.Visible = false;
            btnAddBranch.Visible = true;

            lblBranch.Visible = true;
            lblChiefDirectorate.Visible = false;
            lblDirectorate.Visible = false;
            lblSubDirectorate.Visible = false;
        }
        else if (ddlDepartment.SelectedIndex == 2)
        {
            txtBranch.Visible = false;
            LoadBranch();
            ddlBranch.Visible = true;
            txtChiefDirectorate.Visible = true;
            txtChiefDirectorate.Enabled = true;
            ddlChief_Directorate.Visible = false;
            ddlDirectorate.Visible = false;
            txtDirectorate.Visible = false;
            txtSubDirectorate.Visible = false;
            btnAddBranch.Visible = false;
            btnAddDirectorate.Visible = false;
            btnAddSubDirectorate.Visible = false;
            btnAddChiefDirectorate.Visible = true;

            lblBranch.Visible = true;
            lblChiefDirectorate.Visible = true;
            lblDirectorate.Visible = false;
            lblSubDirectorate.Visible = false;
        }
        else if (ddlDepartment.SelectedIndex == 3)
        {
            txtBranch.Visible = false;
            LoadBranch();
            ddlBranch.Visible = true;
            txtChiefDirectorate.Visible = false;
            txtChiefDirectorate.Enabled = false;
            ddlChief_Directorate.Visible = true;
            ddlDirectorate.Visible = false;
            txtDirectorate.Visible = true;
            txtDirectorate.Enabled = true;
            txtSubDirectorate.Visible = false;
            btnAddBranch.Visible = false;
            btnAddDirectorate.Visible = true;
            btnAddSubDirectorate.Visible = false;
            btnAddChiefDirectorate.Visible = false;


            lblBranch.Visible = true;
            lblChiefDirectorate.Visible = true;
            lblDirectorate.Visible = true;
            lblSubDirectorate.Visible = false;
        }
        else if (ddlDepartment.SelectedIndex == 4)
        {
            txtBranch.Visible = false;
            LoadBranch();
            ddlBranch.Visible = true;
            txtChiefDirectorate.Visible = false;
            txtChiefDirectorate.Enabled = false;
            ddlChief_Directorate.Visible = true;
            ddlDirectorate.Visible = true;
            txtDirectorate.Visible = false;
            txtDirectorate.Enabled = false;
            txtSubDirectorate.Visible = true;
            btnAddBranch.Visible = false;
            btnAddDirectorate.Visible = false;
            btnAddSubDirectorate.Visible = true;
            btnAddChiefDirectorate.Visible = false;

            lblBranch.Visible = true;
            lblChiefDirectorate.Visible = true;
            lblDirectorate.Visible = true;
            lblSubDirectorate.Visible = true;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.LoadChief_Directorate(Convert.ToInt32(ddlBranch.SelectedValue));
        ddlChief_Directorate.Items.Clear();
        ddlChief_Directorate.Enabled = true;
        ddlDirectorate.Items.Clear();
        ddlChief_Directorate.Enabled = true;
        this.LoadChief_Directorate(Convert.ToInt32(ddlBranch.SelectedValue));
        ddlChief_Directorate.Enabled = true;
        
    }
    protected void ddlChief_Directorate_SelectedIndexChanged(object sender, EventArgs e)
    {
        this.LoadDirectorate(Convert.ToInt32(ddlChief_Directorate.SelectedValue));
        ddlDirectorate.Enabled = true;
    }
    public void clear()
    {
        txtBranch.Text = "";
        txtChiefDirectorate.Text = "";
        txtDirectorate.Text = "";
        txtSubDirectorate.Text = "";
        txtBranch.Visible = false;
        ddlBranch.Visible = false;
        ddlChief_Directorate.Visible = false;
        txtChiefDirectorate.Visible = false;
        ddlDirectorate.Visible = false;
        txtDirectorate.Visible = false; ;
        txtSubDirectorate.Visible = false;
        btnAddBranch.Visible = false;
        btnAddChiefDirectorate.Visible = false;
        btnAddDirectorate.Visible = false;
        btnAddSubDirectorate.Visible = false;
    }
    public void showMessage(string message)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + message + "');", true);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    private void Message(string message)
    {
        Response.Write("<script language = javascript>alert('Successfully saved.');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    protected void txtBranch_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtBranch.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Branch name must be alphabets only..");
            txtBranch.Text = string.Empty;
            txtBranch.Focus();
        }


    }

    protected void txtChiefDirectorate_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtChiefDirectorate.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Chief Directorate name must be alphabets only..");
            txtChiefDirectorate.Text = string.Empty;
            txtChiefDirectorate.Focus();
        }
    }
    protected void txtDirectorate_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtDirectorate.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Directorate name must be alphabets only..");
            txtDirectorate.Text = string.Empty;
            txtDirectorate.Focus();
        }
    }
    protected void txtSubDirectorate_TextChanged(object sender, EventArgs e)
    {
        if (!Regex.IsMatch(txtSubDirectorate.Text, @"^[a-zA-Z ]+$"))
        {
            showMessage("Sub Directorate name must be alphabets only..");
            txtSubDirectorate.Text = string.Empty;
            txtSubDirectorate.Focus();
        }
    }
}