﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections;


public partial class _Default : System.Web.UI.Page
{
    ArrayList arraylist1 = new ArrayList();
    ArrayList arraylist2 = new ArrayList();

    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    SqlConnection sqlcon2 = new SqlConnection();
    SqlConnection sqlcon3 = new SqlConnection();
    
    protected void Page_Load(object sender, EventArgs e)
    {

        Page.MaintainScrollPositionOnPostBack = true;
        if (!IsPostBack)
        {
            bindGriview();
            BindListBox1();
            CVsReceived();
          
            string shortlisted = "";
            string IDs = "";

            sqlcon = new SqlConnection(Conn);
            String sql = "Select * from shortlisting_commitee where post_reference = '" + Request.QueryString["id"].ToString() + "' ";
            sqlcon.Open();

            SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
            SqlDataReader dr = sqlcmd.ExecuteReader();

            while (dr.Read())
            {
                string shortlistingID = dr["shortlisting_id"].ToString();

                Session["shortlisting_id"] = shortlistingID;

                dpShortlistingDate.Text = Convert.ToDateTime(dr["shortlising_date"]).ToString("yyyy-MM-dd", null);
                //txtShortlistingNames.Text = dr["shortlisting_names"].ToString();
                txtComments.Text = dr["comments"].ToString();
                dpDateCVsReceived.Text = Convert.ToDateTime(dr["date_CVs_received"]).ToString("yyyy-MM-dd", null);
                shortlisted = dr["shortlistedCandidates"].ToString();

                IDs = dr["idPassport"].ToString();

            }
            dr.Close();
            sqlcon.Close();


            string CandidatesIDs = IDs;
            string Candidates = shortlisted;

            string[] names = Candidates.Split(',');
            string[] id = CandidatesIDs.Split(',');           

            for (int i = 0; i < names.Length; i++)
            {
                ListItem li = new ListItem();

                li.Value = id[i].ToString();

                li.Text = names[i].ToString();

                ListBox2.Items.Add(li);                   

            }
          
        }                 
       
    }
  
    protected void BindListBox1()
    {
        SqlCommand cmd = new SqlCommand(Conn);
        sqlcon.ConnectionString = Conn;
        cmd.Connection = sqlcon;
              
        cmd.CommandText = "BindListbox";
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@post_reference", Request["id"].ToString());

        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        ListBox1.DataSource = dt;
        ListBox1.DataTextField = "FullName";
        ListBox1.DataValueField = "idPassport";
        ListBox1.DataBind();

        if (ListBox1.Items.Count == 0)
        {
            MesageBox("No applications associated with this Reference number!!!!", "home.aspx");
        }

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand(Conn);
        sqlcon.ConnectionString = Conn;
        cmd.Connection = sqlcon;       

        string CandidateName = "";
        string idPassport = "";

        IList<string> items = new List<string>();

        foreach (ListItem item in ListBox2.Items)
        {
            items.Add(item.Text);
            items.Add(item.Value);

            CandidateName += item.Text + ",";
            idPassport += item.Value + ",";   
          
        }               

        try
        {
            cmd.CommandText = "UpdateShortlistingCommitee";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@shortlising_date", SqlDbType.DateTime).Value = Convert.ToDateTime( dpShortlistingDate.Text);
            cmd.Parameters.Add("@date_CVs_received", SqlDbType.DateTime).Value = Convert.ToDateTime( dpDateCVsReceived.Text);
            cmd.Parameters.Add("@comments", SqlDbType.VarChar).Value = txtComments.Text;
            cmd.Parameters.Add("@shortlistedCandidates", SqlDbType.VarChar).Value = CandidateName.TrimEnd(',');
            cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = Request.QueryString["id"];
            cmd.Parameters.Add("@idPassport", SqlDbType.VarChar).Value = idPassport.TrimEnd(',');           

            sqlcon.Open();
            cmd.ExecuteNonQuery();
            sqlcon.Close();

            ShowMessage("Shortlisting Details Updated Successfully");      
        }
        catch
        {


        }        
    
    }

    private void ShowMessage(string message)
    {
        Response.Write("<script language = javascript>alert('Shortlisting Details Updated Successfully');window.location.href='Home.aspx';('" + message + "')</script>");

    }
    private void ClearControls()
    {
        txtComments.Text = "";
        //txtShortlistingNames.Text = "";
        dpShortlistingDate.Text = "";

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        while (ListBox1.Items.Count != 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {               
                    ListBox2.Items.Add(ListBox1.Items[i]);
                    ListBox1.Items.Remove(ListBox1.Items[i]);               
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox1.Items.Count; i++)
            {
                if (ListBox1.Items[i].Selected)
                {
                    if (!arraylist1.Contains(ListBox1.Items[i]))
                    {
                        arraylist1.Add(ListBox1.Items[i]);
                        
                    }
                }
            }
            for (int i = 0; i < arraylist1.Count; i++)
            {
                
                     if (!ListBox2.Items.Contains(((ListItem)arraylist1[i])))
                     {
                         ListBox2.Items.Add(((ListItem)arraylist1[i]));
                         
                     }                    
               
                //ListBox1.Items.Remove(((ListItem)arraylist1[i]));
            }
            ListBox2.SelectedIndex = -1;
        }
        else
        {

            //Response.Write("Please select atleast one in Listbox1 to move");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (ListBox2.SelectedIndex >= 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                if (ListBox2.Items[i].Selected)
                {
                    if (!arraylist2.Contains(ListBox2.Items[i]))
                    {
                        arraylist2.Add(ListBox2.Items[i]);
                        //ListBox2.Items.Remove(((ListItem)arraylist2[i]));
                    }

                }
            }
            for (int i = 0; i < arraylist2.Count; i++)
            {
                if (!ListBox1.Items.Contains(((ListItem)arraylist2[i])))
                {
                    ListBox1.Items.Add(((ListItem)arraylist2[i]));

                    //ListBox2.Items.Remove(((ListItem)arraylist2[i]));
                }
               
                ListBox2.Items.Remove(((ListItem)arraylist2[i]));
            }
            ListBox1.SelectedIndex = -1;
        }
        else
        {
            //Response.Write("Please select atleast one in Listbox2 to move");
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        while (ListBox2.Items.Count != 0)
        {
            for (int i = 0; i < ListBox2.Items.Count; i++)
            {
                ListBox1.Items.Add(ListBox2.Items[i]);
                ListBox2.Items.Remove(ListBox2.Items[i]);
            }
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }

    private void bindGriview()
    {
        SqlCommand cmd2 = new SqlCommand("select * from shortlisting_committee_names where post_reference = '" + Request["id"].ToString() + "'");

        this.sqlcon2.ConnectionString = this.Conn;
        cmd2.Connection = this.sqlcon2;

        SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
        DataTable dt2 = new DataTable();
        da2.Fill(dt2);
        GridView1.DataSource = dt2;
        GridView1.DataBind();
    }

    private DataTable GetData(SqlCommand cmd)
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection(Conn);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        con.Open();
        sda.SelectCommand = cmd;
        sda.Fill(dt);
        return dt;
    }
    protected void OnPaging(object sender, GridViewPageEventArgs e)
    {
        bindGriview();
        GridView1.PageIndex = e.NewPageIndex;
        GridView1.DataBind();
    }

    protected void AddNewRow(object sender, EventArgs e)
    {
        int shortlistingID = Convert.ToInt32(Session["shortlisting_id"]);
        string postRef = Request["id"].ToString();

        string names = ((TextBox)GridView1.FooterRow.FindControl("txtName_Surname")).Text;
        string rank = ((TextBox)GridView1.FooterRow.FindControl("txtRank")).Text;
        string designation = ((TextBox)GridView1.FooterRow.FindControl("txtDesignation")).Text;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "insert into shortlisting_committee_names(post_reference,shortlisting_id,names, rank, designation) " + "values(@post_reference,@shortlisting_id,@names, @rank, @designation)";

        cmd.Parameters.Add("@post_reference", SqlDbType.VarChar).Value = postRef;
        cmd.Parameters.Add("@shortlisting_id", SqlDbType.Int).Value = shortlistingID;
        cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
        cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
        cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();


        bindGriview();
    }

    protected void DeleteRow(object sender, EventArgs e)
    {

        LinkButton lnkRemove = (LinkButton)sender;
        SqlConnection con = new SqlConnection(Conn);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "delete from  shortlisting_committee_names where " + "id=@id";
        cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = lnkRemove.CommandArgument;
        GridView1.DataSource = GetData(cmd);
        GridView1.DataBind();

        bindGriview();
    }
    protected void EditRow(object sender, GridViewEditEventArgs e)
    {


        GridView1.EditIndex = e.NewEditIndex;
        bindGriview();
    }
    protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bindGriview();
    }
    protected void UpdateRow(object sender, GridViewUpdateEventArgs e)
    {
        try
        {

            int id = Convert.ToInt32(((Label)GridView1.Rows[e.RowIndex].FindControl("lblID")).Text);


            string names = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtName_Surname")).Text;
            string rank = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtRank")).Text;
            string designation = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDesignation")).Text;
            SqlConnection con = new SqlConnection(Conn);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update shortlisting_committee_names set names=@names,rank=@rank,designation=@designation " + "where id=@id";
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@names", SqlDbType.VarChar).Value = names;
            cmd.Parameters.Add("@rank", SqlDbType.VarChar).Value = rank;
            cmd.Parameters.Add("@designation", SqlDbType.VarChar).Value = designation;
            GridView1.EditIndex = -1;
            GridView1.DataSource = GetData(cmd);
            GridView1.DataBind();
            
            bindGriview();
        }
        catch
        {


        }
    }
    public void MesageBox(string mgs, string url)
    {
        string script = "window.onload = function(){ alert('";
        script += mgs;
        script += "');";
        script += "window.location = '";
        script += url;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
    }
    protected void dpShortlistingDate_TextChanged(object sender, EventArgs e)
    {

    }
    public void CVsReceived()
    {
        sqlcon3 = new SqlConnection(Conn);

        sqlcon3.Open();
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) as CVs FROM [dbo].[applicants] where post_reference = '" + Request["id"] + "'", sqlcon3);

        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
            txtNoOfCVRecieved.Text = dr["CVs"].ToString();
            txtNoOfCvReleased.Text = dr["CVs"].ToString();
        }
        dr.Close();
        sqlcon3.Close();
    }
    protected void RangeValidator_Init(object sender, EventArgs e)
    {
        ((RangeValidator)sender).MaximumValue = DateTime.Now.ToShortDateString();


    }
}
