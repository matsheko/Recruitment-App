﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        if (!base.IsPostBack)
        {
            NameDiv.Visible = false;
            DisplayDiv.Visible = false;
        }
    }
    protected void LoadBranch()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT branch_id, branch_name from branch ORDER BY branch_name ASC");
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDisplay.DataSource = dataTable;
            this.ddlDisplay.DataTextField = "branch_name";
            this.ddlDisplay.DataValueField = "branch_id";
            this.ddlDisplay.DataBind();
            this.ddlDisplay.Items.Insert(0, "Select One...");
        }
    }
    protected void LoadChief_Directorate()
    {
        SqlCommand cmd = new SqlCommand("SELECT Chief_Dire_id,Chief_Dire_Name from Chief_Directorate ORDER BY Chief_Dire_Name ASC");
        //cmd.Parameters.AddWithValue("@Brach_id", branch_id);
        this.sqlcon.ConnectionString = this.Conn;
        cmd.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDisplay.DataSource = dataTable;
            this.ddlDisplay.DataTextField = "Chief_Dire_Name";
            this.ddlDisplay.DataValueField = "Chief_Dire_id";
            this.ddlDisplay.DataBind();
            this.ddlDisplay.Items.Insert(0, "Select One...");
        }
    }
    protected void LoadDirectorate()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Directorate_id,Directorate_Name from Directorates ORDER BY Directorate_Name ASC");
        //selectCommand.Parameters.AddWithValue("@Chief_Dire_id", Chief_Dire_id);
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDisplay.DataSource = dataTable;
            this.ddlDisplay.DataTextField = "Directorate_Name";
            this.ddlDisplay.DataValueField = "Directorate_id";
            this.ddlDisplay.DataBind();
            this.ddlDisplay.Items.Insert(0, "Select One...");
        }
    }
    protected void Load_Sub_Directorate()
    {
        SqlCommand selectCommand = new SqlCommand("SELECT Sub_Directorate_id,Sub_Directorate_Name from Sub_Directorates ORDER BY Sub_Directorate_Name ASC");
        //selectCommand.Parameters.AddWithValue("@Chief_Dire_id", Chief_Dire_id);
        this.sqlcon.ConnectionString = this.Conn;
        selectCommand.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(selectCommand);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ddlDisplay.DataSource = dataTable;
            this.ddlDisplay.DataTextField = "Sub_Directorate_Name";
            this.ddlDisplay.DataValueField = "Sub_Directorate_id";
            this.ddlDisplay.DataBind();
            this.ddlDisplay.Items.Insert(0, "Select One...");
        }
    }
    protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDepartment.SelectedIndex == 1)
        {
            LoadBranch();
            NameDiv.Visible = false;
            DisplayDiv.Visible = true;
        }
        else if (ddlDepartment.SelectedIndex == 2) 
        {
            LoadChief_Directorate();
            NameDiv.Visible = false;
            DisplayDiv.Visible = true;
        }
        else if (ddlDepartment.SelectedIndex == 3) 
        {
            LoadDirectorate();
            NameDiv.Visible = false;
            DisplayDiv.Visible = true;
        }
        else if (ddlDepartment.SelectedIndex == 4)
        {
            Load_Sub_Directorate();
            NameDiv.Visible = false;
            DisplayDiv.Visible = true;
        }
        else 
        {
            ddlDisplay.Dispose();
            ddlDisplay.Items.Clear();
            NameDiv.Visible = false;
            DisplayDiv.Visible = false;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void ddlChief_Directorate_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    public void clear()
    {
       
    }
    public void showMessage(string message)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                  "alert(' " + message + "');", true);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void ddlDisplay_SelectedIndexChanged(object sender, EventArgs e)
    {
        NameDiv.Visible = true;
        DisplayDiv.Visible = true;
        txtName.Text=ddlDisplay.SelectedItem.Text.ToString();
    }
    public void MesageBox(string mgs, string url)
    {
        string script = "window.onload = function(){ alert('";
        script += mgs;
        script += "');";
        script += "window.location = '";
        script += url;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SqlCommand command = new SqlCommand();
        this.sqlcon.ConnectionString = this.Conn;
        if (this.sqlcon.State == ConnectionState.Closed)
        {
            this.sqlcon.Open();
        }
        command.Connection = this.sqlcon;
        command.CommandText = "[dbo].[Update_Directorates]";
        command.CommandType = CommandType.StoredProcedure;
        command.Parameters.AddWithValue("@id", Convert.ToInt32(ddlDisplay.SelectedValue));
        if (ddlDepartment.SelectedIndex == 1) 
        {
            command.Parameters.AddWithValue("@param", "Branch");
        }
        else if (ddlDepartment.SelectedIndex == 2) 
        {
            command.Parameters.AddWithValue("@param", "Chief_Directorate");
        }
        else if (ddlDepartment.SelectedIndex == 3) 
        {
            command.Parameters.AddWithValue("@param", "Directorate");
        }
        else if (ddlDepartment.SelectedIndex == 4) 
        {
            command.Parameters.AddWithValue("@param", "Sub_Directorate");
        }
        
       
        command.Parameters.AddWithValue("@new_name", this.txtName.Text.ToString());
        command.ExecuteNonQuery();
        this.sqlcon.Close();
        MesageBox("Successfully updated information!!!!", ResolveUrl("~/Administrator/Home.aspx"));
    }
}