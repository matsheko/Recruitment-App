﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class Administrator_Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }
    protected void btnSave_Click1(object sender, EventArgs e)
    {
        Page.MaintainScrollPositionOnPostBack = true;
        try
        {
            string OldPassword = txtOldPassword.Text;
            string ComparePassword = (string)Session["password"];

            if (string.Compare(OldPassword, ComparePassword) == 0)
            {

                SqlCommand cmd = new SqlCommand(Conn);
                sqlcon.ConnectionString = Conn;
                cmd.Connection = sqlcon;

                cmd.CommandText = "ChangePassword";
                cmd.Parameters.AddWithValue("@username", Session["username"].ToString());
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = txtNewPassword.Text;

                sqlcon.Open();
                cmd.ExecuteNonQuery();
                sqlcon.Close();

                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                "alert('Password successfully changed');", true);

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                "alert('Your password could not be changed');", true);

            }
        }

        catch
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                "alert('An error has occured');", true);
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}