﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Net.Mail;
using System.Text;

public partial class Default2 : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtEmail.Focus();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        try
        {
            System.Threading.Thread.Sleep(5000);
            SqlCommand cmd = new SqlCommand(Conn);
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            cmd.CommandText = "SelectUserByEmail";
            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            string Password = dt.Rows[0]["password"].ToString();
            string name = dt.Rows[0]["name"].ToString();
            
            string fromAddress = "RecruitmentSystem@gauteng.gov.za";
            string toAddress = txtEmail.Text;
            string subject = "Password for Recruitment System";

            string SMTP_AUTH_USER = "";
            string SMTP_AUTH_PWD = "";
            MailMessage mmMailer = new MailMessage();

            string body = "Hello " + name + ",<br /><br />" + Environment.NewLine;
            body += "Your password for Recruitment System is : " + Password + "<br /><br />";

            body += "Regards <br /> System Support Team <br /> The Department of Roads and Transport <br /> Directorate: Information Systems";
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            {
                smtp.Host = "10.144.0.9";
                smtp.Port = 25;
                smtp.EnableSsl = false;
                smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                smtp.Credentials = new NetworkCredential(SMTP_AUTH_USER, SMTP_AUTH_PWD);
                smtp.Timeout = 50000;

            }

            mmMailer.From = new MailAddress(fromAddress);
            mmMailer.To.Add(toAddress);

            mmMailer.Subject = subject;
            mmMailer.Body = body;
            mmMailer.IsBodyHtml = true;
            smtp.Send(mmMailer);

            txtEmail.Text = "";

            ScriptManager.RegisterStartupScript(this, this.GetType(), "popup",
                 "alert('Your password has been sent to your email address');", true);
        }
        catch
        {

        }
        

    }                    
}