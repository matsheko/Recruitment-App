﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;

public partial class _Default : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand();
            sqlcon.ConnectionString = Conn;
            cmd.Connection = sqlcon;

            sqlcon.Open();

            cmd.CommandText = "sp_checkuser";
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@username", txtUsername.Text);
            cmd.Parameters.AddWithValue("@password", txtPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Session["userID"] = dr["userID"].ToString();
                    Session["Username"] = dr["username"].ToString();
                    Session["Persal"] = dr["persal"].ToString();
                    Session["Password"] = dr["password"].ToString();
                    Session["Role"] = dr["role"].ToString();
                    Session["name"] = dr["name"].ToString();
                    Session["Surname"] = dr["Surname"].ToString();
                }
                Response.Redirect("administrator/home.aspx");

                //if (Session["Role"].ToString() == "Admin")
                //{
                //    Response.Redirect("administrator/home.aspx");
                //}
                //else if (Session["Role"].ToString() == "Normal user")
                //{
                //    Response.Redirect("normal user/default.aspx");
                //}
                
                //else if (Session["Role"].ToString() == "Manager")
                //{
                //    Response.Redirect("Manager/default.aspx");
                //}
                dr.Close();

            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Login Credintials')</script>");
            }
        }
        catch
        {

        }
    }
}