﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
        Page.MaintainScrollPositionOnPostBack = true;

        if (Session.Count == 0)
        {
            Response.Redirect("../session.aspx");
        }
        else
        {
            lblUser.Text = Session["name"].ToString() + " " + Session["Surname"].ToString();
        }
    }


    protected void lbtnLogout_Click(object sender, EventArgs e)
    {
        if (Session["userID"] != null)
        {
            Session["Username"] = null;
            Session["Password"] = null;
            Session.Abandon();
            Response.Redirect("../default.aspx");
        }
    }
  
  
   
    
    protected void lbtnChangePass_Click(object sender, EventArgs e)
    {
        if (Session["username"] != null)
        {
            Response.Redirect("../administrator/changepassword.aspx");

        }
    }
}
