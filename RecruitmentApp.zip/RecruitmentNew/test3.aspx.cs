﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Net;
using System.Configuration;
using System.Globalization;
using System.Collections;
using System.Collections.Specialized;


public partial class test3 : System.Web.UI.Page
{
    String Conn = ConfigurationManager.ConnectionStrings["RecruitmentDBConnectionString"].ConnectionString;
    SqlConnection sqlcon = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        string agencies = "";
        sqlcon = new SqlConnection(Conn);
        String sql = "Select * from PostDetails where Post_ref_no = 'DRT/FM/2015/21' ";
        sqlcon.Open();

        SqlCommand sqlcmd = new SqlCommand(sql, sqlcon);
        SqlDataReader dr = sqlcmd.ExecuteReader();

        while (dr.Read())
        {                     

             agencies = dr["advertising_agency"].ToString();   
            

        }
        dr.Close();
        sqlcon.Close();




        string bindagencies = agencies;


        string[] agency_collections = bindagencies.Split(',');

        for (int i = 0; i < agency_collections.Length; i++)
        {
            ListItem li = new ListItem();

            li.Text = agency_collections[i].ToString();

            //if (ListBox1.Items.Contains(li.Text[i]
            //{

            //}

            //ListBox1.Items.Add(li);

        }


        LoadAgencies();
          
    }
    public void LoadAgencies()
    {
        SqlCommand Command = new SqlCommand("SELECT * from advertising_agency");
        this.sqlcon.ConnectionString = this.Conn;
        Command.Connection = this.sqlcon;
        SqlDataAdapter adapter = new SqlDataAdapter(Command);
        DataTable dataTable = new DataTable();
        adapter.Fill(dataTable);
        if (dataTable.Rows.Count > 0)
        {
            this.ListBox1.DataSource = dataTable;
            this.ListBox1.DataTextField = "advertising_agency_name";
            this.ListBox1.DataValueField = "advertising_agency_id";
            this.ListBox1.DataBind();
            ListBox1.AppendDataBoundItems = true;

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //foreach (ListItem item in ListBox1.Items)
        //{
        //    if (item.Selected)
        //    {
        //        try
        //        {
        //            string agencies = item.Text + ",";
        //            string trimmed = agencies.TrimEnd(',');
        //            Response.Write(trimmed);
        //            //cmd.Parameters["@CountryVisited"].Value = item.Text;
        //            //cmd.ExecuteNonQuery();
        //            //Label1.Text = "Data Inserted";

        //        }
        //        catch 
        //        {
        //            //Label1.Text = ex.Message;
        //        }
        //    }
        //}
        
    }
}